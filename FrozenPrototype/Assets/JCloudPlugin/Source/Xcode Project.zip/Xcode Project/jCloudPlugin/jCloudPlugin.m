//
//  jCloudPlugin.m
//  jCloudPlugin
//
//  Created by Jérémie Di Prizio on 05/11/11.
//  Copyright (c) 2011-2013 jemast software.
//


#import <CommonCrypto/CommonDigest.h>

#import "jCloudPlugin.h"
#import "CloudDocumentManager.h"
#import "CloudDataManager.h"

// EXTERN DECLATIONS FOR UNMANAGED TO MANAGED CALLBACK METHODS
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
EXTERN_API_C(void) UnitySendMessage(const char *object, const char *method, const char *message) __attribute__((weak));
#elif TARGET_OS_MAC
typedef void ManagedStateCallbackPointer(NSInteger, NSInteger);
typedef void ManagedStatusCallbackPointer(NSInteger, NSInteger, NSInteger);
typedef void ManagedProgressCallbackPointer(NSInteger, float);
#endif






@interface jCloudPlugin ()

- (void)notifyCloudDocumentManagerDidChangeStatus:(CloudDocumentManager *)manager success:(BOOL)success error:(int)error;

@end



@implementation jCloudPlugin

@synthesize stateChangeCallbackPointer, statusChangeCallbackPointer, progressChangeCallbackPointer;


// Quick and dirty singleton implementation
+ (jCloudPlugin *)sharedInstance {
    static dispatch_once_t pred = 0;
    __strong static id _sharedObject = nil;
    dispatch_once(&pred, ^{
        _sharedObject = [[self alloc] init];
    });
    return _sharedObject;
}


//////////////////////////////////////
// Initialization & Dealloc Methods // 
//////////////////////////////////////

#pragma mark Initialization & Dealloc Methods

- (id)init {
    if ((self = [super init])) {
        currentIdentifier = 0;
        cloudDocumentManagerDictionary = [[NSMutableDictionary dictionary] retain];
        cloudDocumentPathDictionary = [[NSMutableDictionary dictionary] retain];
    }
    
    return self;
}

- (void)dealloc {
    [cloudDocumentManagerDictionary release];
    [cloudDocumentPathDictionary release];
    
    [super dealloc];
}


///////////////////////////////////////////////////////////
// Methods For Interacting With Cloud Document Managers // 
///////////////////////////////////////////////////////////

#pragma mark Methods For Interacting Witth Cloud Document Managers

- (int)prepareCloudDocumentManagerAtPath:(NSString *)path isDirectory:(BOOL)directory {
    // Prepare a new cloud document manager and put it in our dictionary
    @synchronized(self) {
        CloudDocumentManager *manager = [cloudDocumentPathDictionary objectForKey:path];
        if (manager != nil) {
            manager.accessCount++;
            return [[manager documentUniqueIdentifier] intValue];
        } else {
            NSNumber *uniqueIdentifier = [NSNumber numberWithInt:currentIdentifier];
            manager = [CloudDocumentManager prepareDataDocumentAtPath:path isDirectory:directory uniqueIdentifier:uniqueIdentifier delegate:self];
            manager.accessCount++;
            [cloudDocumentManagerDictionary setObject:manager forKey:uniqueIdentifier];
            [cloudDocumentPathDictionary setObject:manager forKey:path];
            return currentIdentifier++;            
        }
    }
}

- (BOOL)dismissCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier {
    CloudDocumentManager *manager = [cloudDocumentManagerDictionary objectForKey:uniqueIdentifier];
    if (manager == nil)
        return NO;

    // Dismiss document
    @synchronized(self) { // synchronize, we don't want to dismiss while we're messaging
        manager.accessCount--;
        
        if (manager.accessCount == 0) {
            [cloudDocumentManagerDictionary removeObjectForKey:uniqueIdentifier];
            [cloudDocumentPathDictionary removeObjectForKey:manager.documentPath];
        }
    }
    
    return YES;
}

- (NSInteger)getStateForCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier {
    // Retrieve corresponding cloud document manager
    CloudDocumentManager *manager = [cloudDocumentManagerDictionary objectForKey:uniqueIdentifier];
    if (manager == nil)
        return 0;
    
    // Return current state
    return manager.documentState;
}

- (BOOL)createOrOpenCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier {
    // Retrieve corresponding cloud document manager
    CloudDocumentManager *manager = [cloudDocumentManagerDictionary objectForKey:uniqueIdentifier];
    if (manager == nil)
        return NO;
    
    // Create or open document async
    [manager createOrOpenDocumentWithCompletionHandler:^(BOOL success, id data, int error) {
        [self notifyCloudDocumentManagerDidChangeStatus:manager success:success error:error];
    }];
    
    return YES;
}

- (BOOL)createCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier {
    // Retrieve corresponding cloud document manager
    CloudDocumentManager *manager = [cloudDocumentManagerDictionary objectForKey:uniqueIdentifier];
    if (manager == nil)
        return NO;
    
    // Open document async
    [manager createDocumentWithCompletionHandler:^(BOOL success, id data, int error) {
        [self notifyCloudDocumentManagerDidChangeStatus:manager success:success error:error];
    }];
    
    return YES;
}

- (BOOL)openCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier {
    // Retrieve corresponding cloud document manager
    CloudDocumentManager *manager = [cloudDocumentManagerDictionary objectForKey:uniqueIdentifier];
    if (manager == nil)
        return NO;
    
    // Open document async
    [manager openDocumentWithCompletionHandler:^(BOOL success, id data, int error) {
        [self notifyCloudDocumentManagerDidChangeStatus:manager success:success error:error];
    }];
    
    return YES;
}

- (BOOL)deleteCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier deletedPointer:(char *)deletedPointer {
    // Retrieve corresponding cloud document manager
    CloudDocumentManager *manager = [cloudDocumentManagerDictionary objectForKey:uniqueIdentifier];
    if (manager == nil)
        return NO;
    
    // Ask for document deletion async
    [manager deleteDocumentWithCompletionHandler:^(BOOL success, id data, int error) {
        if (success)
            *deletedPointer = [(NSNumber *)data charValue];
        
        [self notifyCloudDocumentManagerDidChangeStatus:manager success:success error:error];
    }];
    
    return YES;
}


- (BOOL)writeContents:(NSData *)contents toCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier {
    // Retrieve corresponding cloud document manager
    CloudDocumentManager *manager = [cloudDocumentManagerDictionary objectForKey:uniqueIdentifier];
    if (manager == nil)
        return NO;

    // Write contents
    return [manager writeContents:contents];
}

- (NSData *)readContentsOfCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier {
    // Retrieve corresponding cloud document manager
    CloudDocumentManager *manager = [cloudDocumentManagerDictionary objectForKey:uniqueIdentifier];
    if (manager == nil)
        return nil;
    
    // Read contents
    return [manager readContents];
}

- (BOOL)getExistenceOfCloudDocumentWithUniqueIdentifier:(NSNumber *)uniqueIdentifier existsPointer:(char *)existsPointer {
    // Retrieve corresponding cloud document manager
    CloudDocumentManager *manager = [cloudDocumentManagerDictionary objectForKey:uniqueIdentifier];
    if (manager == nil) {
        return NO;
    }
    
    [manager checkExistenceWithCompletionHandler:^(BOOL success, id data, int error) {
        if (success)
            *existsPointer = [(NSNumber *)data charValue];
        
        [self notifyCloudDocumentManagerDidChangeStatus:manager success:success error:error];
    }];
    
    return YES;
}

- (BOOL)getModificationDateOfCloudDocumentWithUniqueIdentifier:(NSNumber *)uniqueIdentifier modificationDatePointer:(uint64_t *)modificationDatePointer {
    // Retrieve corresponding cloud document manager
    CloudDocumentManager *manager = [cloudDocumentManagerDictionary objectForKey:uniqueIdentifier];
    if (manager == nil)
        return NO;
    
    [manager getModificationDateWithCompletionHandler:^(BOOL success, id data, int error) {
        if (success)
            *modificationDatePointer = [(NSDate *)data timeIntervalSince1970];
        
        [self notifyCloudDocumentManagerDidChangeStatus:manager success:success error:error];
    }];
    
    return YES;
}

- (BOOL)copyCloudDocumentWithUniqueIdentifier:(NSNumber *)uniqueIdentifier destination:(NSString *)path overwrite:(BOOL)overwrite {
    // Retrieve corresponding cloud document manager
    CloudDocumentManager *manager = [cloudDocumentManagerDictionary objectForKey:uniqueIdentifier];
    if (manager == nil)
        return NO;
    
    [manager copyToPath:path overwrite:overwrite withCompletionHandler:^(BOOL success, id data, int error) {
        [self notifyCloudDocumentManagerDidChangeStatus:manager success:success error:error];
    }];
    
    return YES;
}

- (BOOL)moveCloudDocumentWithUniqueIdentifier:(NSNumber *)uniqueIdentifier destination:(NSString *)path overwrite:(BOOL)overwrite {
    // Retrieve corresponding cloud document manager
    CloudDocumentManager *manager = [cloudDocumentManagerDictionary objectForKey:uniqueIdentifier];
    if (manager == nil)
        return NO;
    
    [manager moveToPath:path overwrite:overwrite withCompletionHandler:^(BOOL success, id data, int error) {
        [self notifyCloudDocumentManagerDidChangeStatus:manager success:success error:error];
    }];
    
    return YES;
}

- (BOOL)getHasConflictVersionsOfCloudDocumentWithUniqueIdentifier:(NSNumber *)uniqueIdentifier conflictPointer:(char *)conflictPointer {
    // Retrieve corresponding cloud document manager
    CloudDocumentManager *manager = [cloudDocumentManagerDictionary objectForKey:uniqueIdentifier];
    if (manager == nil)
        return NO;
    
    [manager getHasConflictVersionsWithCompletionHandler:^(BOOL success, id data, int error) {
        if (success)
            *conflictPointer = [(NSNumber *)data charValue];
        
        [self notifyCloudDocumentManagerDidChangeStatus:manager success:success error:error];
    }];
    
    return YES;
}

- (BOOL)getAllVersionsOfCloudDocumentWithUniqueIdentifier:(NSNumber *)uniqueIdentifier versions:(JCloudDocumentVersions *)versions {
    // Retrieve corresponding cloud document manager
    CloudDocumentManager *manager = [cloudDocumentManagerDictionary objectForKey:uniqueIdentifier];
    if (manager == nil)
        return NO;
    
    [manager getAllVersionsWithCompletionHandler:^(BOOL success, id data, int error) {
        if (success && data != nil && versions != nil) {
            // Prepare versions metadata storage
            (*versions).versionsCount = [(NSArray*)data count];
            (*versions).versionsUniqueIdentifiers = malloc((*versions).versionsCount*sizeof(NSInteger *));
            (*versions).versionsUniqueIdentifiersLengthes = malloc((*versions).versionsCount*sizeof(NSInteger));
            (*versions).versionsModificationDates = malloc((*versions).versionsCount*sizeof(uint64_t));
            (*versions).versionsIsCurrent = malloc((*versions).versionsCount*sizeof(uint8_t));
            
            // Create MD5 hash of current versions status & save metadata
            NSMutableData *hash = [[NSMutableData alloc] init];
            int offset = 0;
            for (NSFileVersion *version in (NSArray*)data) {
                NSData *persistentIdentifier = [NSKeyedArchiver archivedDataWithRootObject:version.persistentIdentifier];
                
                [hash appendData:persistentIdentifier];
                [hash appendData:[NSKeyedArchiver archivedDataWithRootObject:version.modificationDate]];
                
                // Save metadata
                (*versions).versionsUniqueIdentifiersLengthes[offset] = [persistentIdentifier length];
                (*versions).versionsUniqueIdentifiers[offset] = malloc([persistentIdentifier length]);
                memcpy((*versions).versionsUniqueIdentifiers[offset], [persistentIdentifier bytes], [persistentIdentifier length]);
                
                (*versions).versionsModificationDates[offset] = (uint64_t)[version.modificationDate timeIntervalSince1970];
                (*versions).versionsIsCurrent[offset] = !version.conflict;
                
                offset++;
            }
            
            // Put in returnable memory
            unsigned char result[16];
            CC_MD5(hash.bytes, (unsigned int)hash.length, result);
            NSString *md5Hash = [NSString stringWithFormat:
                                 @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
                                 result[0], result[1], result[2], result[3],
                                 result[4], result[5], result[6], result[7],
                                 result[8], result[9], result[10], result[11],
                                 result[12], result[13], result[14], result[15]
                                 ];
            NSUInteger md5HashLength = [md5Hash lengthOfBytesUsingEncoding:NSUTF8StringEncoding] + 1; // Plus one for null terminator
            char *versionsHash = malloc(md5HashLength);
            memcpy(versionsHash, [md5Hash UTF8String], md5HashLength);
            
            [hash release];
            
            (*versions).versionsHash = (NSInteger *)versionsHash;
        }
        
        [self notifyCloudDocumentManagerDidChangeStatus:manager success:success error:error];
    }];
    
    return YES;
}

- (BOOL)openCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier versionIdentifier:(NSData *)versionIdentifier {
    // Retrieve corresponding cloud document manager
    CloudDocumentManager *manager = [cloudDocumentManagerDictionary objectForKey:uniqueIdentifier];
    if (manager == nil)
        return NO;
    
    // Open document async
    [manager openDocumentWithVersionIdentifier:versionIdentifier completionHandler:^(BOOL success, id data, int error) {
        [self notifyCloudDocumentManagerDidChangeStatus:manager success:success error:error];
    }];
    
    return YES;
}

- (BOOL)pickCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier versionsHash:(NSString *)md5Hash versionIdentifier:(NSData *)versionIdentifier {
    // Retrieve corresponding cloud document manager
    CloudDocumentManager *manager = [cloudDocumentManagerDictionary objectForKey:uniqueIdentifier];
    if (manager == nil)
        return NO;
    
    // Pick document async
    [manager pickDocumentWithVersionIdentifier:versionIdentifier versionsHash:md5Hash completionHandler:^(BOOL success, id data, int error) {
        [self notifyCloudDocumentManagerDidChangeStatus:manager success:success error:error];
    }];
    
    return YES;
}


/////////////////////////////////////////////////
// Private Methods                             //
/////////////////////////////////////////////////

#pragma mark Private methods

- (void)notifyCloudDocumentManagerDidChangeStatus:(CloudDocumentManager *)manager success:(BOOL)success error:(int)error {
    BOOL shouldProceed;
    NSInteger uid;
    
    @synchronized(self) { // This needs to be synchronized as we don't want the manager to be dimissed while sending
        shouldProceed = ([cloudDocumentManagerDictionary objectForKey:[manager documentUniqueIdentifier]] == manager);
        uid = [manager.documentUniqueIdentifier integerValue];
    }
    
    // Do we need to proceed with this or has document be dimissed?
    if (shouldProceed) {
        // Compute message to send
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
        NSString *message = [NSString stringWithFormat:@"%i.%i.%i", uid, success, error];
#endif
        
        dispatch_async(dispatch_get_main_queue(),^ {
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
            UnitySendMessage("JCloudManager", "DocumentStatusDidChange", [message UTF8String]);
#elif TARGET_OS_MAC
            if (statusChangeCallbackPointer != 0) // we don't want to BAD_ACCESS
                (*((ManagedStatusCallbackPointer *)statusChangeCallbackPointer))(uid, success, error);
#endif
        });
    }
}


/////////////////////////////////////////////////
// CloudDocumentManagerDelegate Implementation //
/////////////////////////////////////////////////

#pragma mark CloudDocumentManagerDelegate Implementation

- (void)cloudDocumentManagerDidChangeState:(CloudDocumentManager *)manager state:(NSInteger)state {
    BOOL shouldProceed;
    NSInteger uid;
    
    @synchronized(self) { // This needs to be synchronized as we don't want the manager to be dimissed while sending
        shouldProceed = ([cloudDocumentManagerDictionary objectForKey:[manager documentUniqueIdentifier]] == manager);
        uid = [manager.documentUniqueIdentifier integerValue];
    }
        
    // Do we need to proceed with this or has document be dimissed?
    if (shouldProceed) {
        // Compute message to send
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
        NSString *message = [NSString stringWithFormat:@"%i.%i", uid, state];
#endif
            
        dispatch_async(dispatch_get_main_queue(),^ {
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
            UnitySendMessage("JCloudManager", "DocumentStateDidChange", [message UTF8String]);
#elif TARGET_OS_MAC
            if (stateChangeCallbackPointer != 0) // we don't want to BAD_ACCESS
                (*((ManagedStateCallbackPointer *)stateChangeCallbackPointer))(uid, state);
#endif
        });
    }
}

- (void)cloudDocumentManagerDidChangeProgress:(CloudDocumentManager *)manager progress:(float)progress {
    BOOL shouldProceed;
    NSInteger uid;
    
    @synchronized(self) { // This needs to be synchronized as we don't want the manager to be dimissed while sending
        shouldProceed = ([cloudDocumentManagerDictionary objectForKey:[manager documentUniqueIdentifier]] == manager);
        uid = [manager.documentUniqueIdentifier integerValue];
    }
    
    // Do we need to proceed with this or has document be dimissed?
    if (shouldProceed) {
        // Compute message to send
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
        NSString *message = [NSString stringWithFormat:@"%i;%f", uid, progress];
#endif
        
        dispatch_async(dispatch_get_main_queue(),^ {
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
            UnitySendMessage("JCloudManager", "DocumentProgressDidChange", [message UTF8String]);
#elif TARGET_OS_MAC
            if (progressChangeCallbackPointer != 0) // we don't want to BAD_ACCESS
                (*((ManagedProgressCallbackPointer *)progressChangeCallbackPointer))(uid, progress);
#endif
        });
    }
}


@end
