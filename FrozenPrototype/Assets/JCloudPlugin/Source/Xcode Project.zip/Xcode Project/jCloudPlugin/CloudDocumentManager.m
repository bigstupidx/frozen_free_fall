//
//  CloudDocumentManager.m
//  CloudDocumentManager
//
//  Created by Jérémie Di Prizio on 04/11/11.
//  Copyright (c) 2011-2013 jemast software.
//

#import <CommonCrypto/CommonDigest.h>

#import "CloudDocumentManager.h"
#import "JCPDocument.h"



// Private methods & properties declaration
@interface CloudDocumentManager ()

- (BOOL)isCloudAvailable;
- (void)createOrOpenCloudDocument;
- (void)createOrOpenLocalDocument;
- (void)createCloudDocument;
- (void)createLocalDocument;
- (void)deleteCloudDocument;
- (void)deleteLocalDocument;
- (void)closeDocumentWithNotification:(BOOL)notification;
- (void)startQueryTimeoutTimer;
- (void)stopQueryTimeoutTimer;
- (void)startDownloadTimeoutTimer;
- (void)stopDownloadTimeoutTimer;

@property (nonatomic, readonly) NSURL *urlForUbiquityContainerIdentifier;
@property (nonatomic, readonly) NSURL *documentsDirectoryURL;


@end




@implementation CloudDocumentManager

@dynamic urlForUbiquityContainerIdentifier, documentsDirectoryURL;
@synthesize documentPath, documentState, documentDelegate, documentUniqueIdentifier, accessCount;


///////////////////////////////////////
// Internal Class & Instance Methods //
///////////////////////////////////////

#pragma mark Internal Class & Instance Methods

// Persistent data path sent by Unity
static NSString *persistentDataPath = nil;
+ (void)setPersistentDataPath:(NSString *)path {
    [persistentDataPath release];
    persistentDataPath = [path retain];
}

static BOOL didCheckUbiquityStatus = false;

+ (NSURL *)urlForUbiquityContainerIdentifier {
    // This is our iCloud path our nil if no-iCloud
    static NSURL *urlForUbiquityContainerIdentifier = nil;
    
    if (!didCheckUbiquityStatus) {
        // Check iCloud methods are available
        if (![[NSFileManager defaultManager] respondsToSelector:@selector(URLForUbiquityContainerIdentifier:)])
            return nil;
        
        @synchronized ([NSNull null]) {
            NSFileManager *asyncFileManager = [[NSFileManager alloc] init];
            urlForUbiquityContainerIdentifier = [[[asyncFileManager URLForUbiquityContainerIdentifier:nil] URLByAppendingPathComponent:@"Documents" isDirectory:YES] retain];
            if (urlForUbiquityContainerIdentifier != nil)
                [asyncFileManager createDirectoryAtURL:urlForUbiquityContainerIdentifier withIntermediateDirectories:NO attributes:nil error:nil];
            [asyncFileManager release];
        }
        
        didCheckUbiquityStatus = true;
    }
    
    return urlForUbiquityContainerIdentifier;
}

+ (void)resetUbiquityStatus {
    didCheckUbiquityStatus = false;
}

- (NSURL *)urlForUbiquityContainerIdentifier {
    return [CloudDocumentManager urlForUbiquityContainerIdentifier];
}

// This is our local path for fallback if no iCloud
+ (NSURL *)documentsDirectoryURL {
    static NSURL *documentsDirectoryURL = nil;
    
    if (documentsDirectoryURL == nil) {
        @synchronized ([NSNull null]) {
            NSFileManager *asyncFileManager = [[NSFileManager alloc] init];
            documentsDirectoryURL = [[[asyncFileManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] objectAtIndex:0] retain];
            
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
#elif TARGET_OS_MAC
            // If we ain't sandboxed, fall back to persistent data path
            if ([[[NSProcessInfo processInfo] environment] objectForKey:@"APP_SANDBOX_CONTAINER_ID"] == nil) {
                [documentsDirectoryURL release];
                documentsDirectoryURL = [[NSURL fileURLWithPath:persistentDataPath isDirectory:YES] retain];
            }
#endif
            
            [asyncFileManager release];
        }
    }
    
    return documentsDirectoryURL;
}

- (NSURL *)documentsDirectoryURL {
    return [CloudDocumentManager documentsDirectoryURL];
}


- (BOOL)isCloudAvailable {
    // Check if our URL for ubiquity container identifier is valid
    return (self.urlForUbiquityContainerIdentifier != nil);
}

//////////////////////////////////////
// Initialization & Dealloc Methods //
//////////////////////////////////////

#pragma mark Initialization & Dealloc Methods

- (void)dealloc {
    // Close document
    [self closeDocumentWithNotification:NO];
    
    // Make sure we aren't observing any notification anymore
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    // Here for reference
    documentDelegate = nil;
    
    // Release stuff
    [metadataQuery release];
    [documentPath release];
    [documentUniqueIdentifier release];
    [documentCloudURL release];
    [documentLocalURL release];
    [documentCopyMoveURL release];
    
    [documentTimeoutQueryTime release];
    [documentTimeoutDownloadTime release];
    if (documentTimeoutTimer != nil) {
        dispatch_source_cancel(documentTimeoutTimer);
        dispatch_release(documentTimeoutTimer);
    }
    
    [documentVersionIdentifier release];
    [documentVersionsHash release];
    
    dispatch_release(managerQueue);
    
    [super dealloc];
}

- (CloudDocumentManager *)initWithPrepareDataDocumentAtPath:(NSString *)path isDirectory:(BOOL)directory uniqueIdentifier:(NSNumber *)uniqueIdentifier delegate:(id)delegate {
    // Failsafe
    if (path == nil)
        return self;
    
    if ((self = [super init])) {
        // Prepare the metadata query object
        metadataQuery = [[NSMetadataQuery alloc] init];
        [metadataQuery setSearchScopes:[NSArray arrayWithObject:NSMetadataQueryUbiquitousDocumentsScope]];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(metadataQueryDidStartGatheringNotification:) name:NSMetadataQueryDidStartGatheringNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(metadataQueryGatheringProgressNotification:) name:NSMetadataQueryGatheringProgressNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(metadataQueryDidFinishGatheringNotification:) name:NSMetadataQueryDidFinishGatheringNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(metadataQueryDidUpdateNotification:) name:NSMetadataQueryDidUpdateNotification object:nil];
        
        // Save document path & directory status
        documentPath = [path retain];
        documentIsDirectory = directory;
        
        // Determine cloud & local URLs
        documentCloudURL = [[self.urlForUbiquityContainerIdentifier URLByAppendingPathComponent:documentPath isDirectory:documentIsDirectory] retain];
        documentLocalURL = [[self.documentsDirectoryURL URLByAppendingPathComponent:documentPath isDirectory:documentIsDirectory] retain];
        
        // Prepare state
        documentState = kCloudDocumentStateClosed;
        documentIsUbiquitous = NO;
        
        // Retain unique ID
        documentUniqueIdentifier = [uniqueIdentifier retain];
        
        // Keep reference to delegate
        documentDelegate = delegate;
        
        //self.managerQueue = [[[NSOperationQueue alloc] init] autorelease];
        managerQueue = dispatch_queue_create([[NSString stringWithFormat:@"com.jemast.jCloudPlugin-DocumentManager-%ld", (long)[documentUniqueIdentifier integerValue]] UTF8String], DISPATCH_QUEUE_SERIAL);
    }
    
    return self;
}

+ (CloudDocumentManager *)prepareDataDocumentAtPath:(NSString *)path isDirectory:(BOOL)directory uniqueIdentifier:(NSNumber *)uniqueIdentifier delegate:(id)delegate {
    return [[[CloudDocumentManager alloc] initWithPrepareDataDocumentAtPath:path isDirectory:directory uniqueIdentifier:uniqueIdentifier delegate:delegate] autorelease];
}


//////////////////////////////////////////
// Public Document Manipulation Methods //
//////////////////////////////////////////

#pragma mark Public Document Manipulation Methods

- (void)createOrOpenDocumentWithCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler {
    dispatch_async(managerQueue, ^{
        // Mark document as processing and strategy as create or open
        documentState = kCloudDocumentStateProcessing;
        documentStrategy = kCloudDocumentStrategyCreateOrOpen;
        
        // Notify delegate of state change
        if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeState:state:)])
            [self.documentDelegate cloudDocumentManagerDidChangeState:self state:documentState];
        
        // Save completion handler
        completionHandlerBlock = Block_copy(completionHandler);
        
        // Check wether iCloud is available or not
        if ([self isCloudAvailable]) {
            // If iCloud is available, look if this document exists in iCloud
            [self createOrOpenCloudDocument];
        } else {
            // If iCloud isn't available, just make a local document
            [self createOrOpenLocalDocument];
        }
    });
}

- (void)createDocumentWithCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler {
    dispatch_async(managerQueue, ^{
        // Mark document as processing and strategy as create only
        documentState = kCloudDocumentStateProcessing;
        documentStrategy = kCloudDocumentStrategyCreate;
        
        // Notify delegate of state change
        if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeState:state:)])
            [self.documentDelegate cloudDocumentManagerDidChangeState:self state:documentState];
        
        // Save completion handler
        completionHandlerBlock = Block_copy(completionHandler);
        
        // Check wether iCloud is available or not
        if ([self isCloudAvailable]) {
            // If iCloud is available, look if this document exists in iCloud
            [self createCloudDocument];
        } else {
            // If iCloud isn't available, just make a local document
            [self createLocalDocument];
        }
    });
}

- (void)openDocumentWithCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler {
    dispatch_async(managerQueue, ^{
        // Mark document as processing and strategy as open only
        documentState = kCloudDocumentStateProcessing;
        documentStrategy = kCloudDocumentStrategyOpen;
        
        // Notify delegate of state change
        if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeState:state:)])
            [self.documentDelegate cloudDocumentManagerDidChangeState:self state:documentState];
        
        // Save completion handler
        completionHandlerBlock = Block_copy(completionHandler);
        
        // Check wether iCloud is available or not
        if ([self isCloudAvailable]) {
            // If iCloud is available, look if this document exists in iCloud
            [self createOrOpenCloudDocument];
        } else {
            // If iCloud isn't available, just make a local document
            [self createOrOpenLocalDocument];
        }
    });
}

- (void)deleteDocumentWithCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler {
    dispatch_async(managerQueue, ^{
        // Mark document as processing and strategy as delete
        documentState = kCloudDocumentStateProcessing;
        documentStrategy = kCloudDocumentStrategyDelete;
        
        // Notify delegate of state change
        if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeState:state:)])
            [self.documentDelegate cloudDocumentManagerDidChangeState:self state:documentState];
        
        // Save completion handler
        completionHandlerBlock = Block_copy(completionHandler);
        
        // Check wether iCloud is available or not
        if ([self isCloudAvailable]) {
            // If iCloud is available, look if this document exists in iCloud
            [self deleteCloudDocument];
        } else {
            // If iCloud isn't available, just delete local document
            [self deleteLocalDocument];
        }
    });
}

- (BOOL)writeContents:(id)contents {
    // Attempt to set new contents -- we can write regardless of status
    return [document setContents:contents];
}

- (NSData *)readContents {
    // Make sure it is safe to read
    if (documentState != kCloudDocumentStateNormal)
        return nil;
    
    // Return document contents
    if (!documentIsDirectory)
        return [document fileData];
    else {
        // File data is actually a NSArray of files & directories, we need to serialize this in NSData
        NSArray *directoryContents = [[document fileData] copy]; // Make a copy because it might change while we parse it
        
        // First parse to determine total string size
        NSUInteger totalStringSize = 0;
        for (NSURL *contentURL in directoryContents) {
            totalStringSize += strlen([[contentURL.pathComponents lastObject] UTF8String]);
        }
        
        // Data structure is : itemCount as uint32_t then for each URL, isDirectory as uint8_t, pathLength as uint32_t and then pathString as const char *
        NSUInteger totalBytesSize = sizeof(uint32_t) + directoryContents.count * (sizeof(uint8_t) + sizeof(uint32_t)) + totalStringSize;
        char *bytes = malloc(totalBytesSize);
        
        // Write itemCount
        *((uint32_t *)(&(bytes[0]))) = (uint32_t)directoryContents.count;
        
        // Second parse for writing isDirectory/pathLength/pathString for each URL
        NSUInteger offset = sizeof(uint32_t);
        for (NSURL *contentURL in directoryContents) {
            // Check wether URL is directory
            NSError *getResourceValueError = nil;
            NSNumber *isDirectoryValue = nil;
            [contentURL getResourceValue:&isDirectoryValue forKey:NSURLIsDirectoryKey error:&getResourceValueError];
            if (getResourceValueError != nil)
                continue;
            
            // Set value in our data structure
            *((uint8_t *)(&(bytes[offset]))) = [isDirectoryValue boolValue];
            
            // Get path length
            NSUInteger pathLength = strlen([[contentURL.pathComponents lastObject] UTF8String]);
            
            // Set value in our data structure
            *((uint32_t *)(&(bytes[offset + sizeof(uint8_t)]))) = (uint32_t)pathLength;
            
            // Set path string in our data structe
            memcpy(&(bytes[offset + sizeof(uint8_t) + sizeof(uint32_t)]), [[contentURL.pathComponents lastObject] UTF8String], pathLength);
            
            // Increment to next offset
            offset += sizeof(uint8_t) + sizeof(uint32_t) + pathLength;
        }
        
        // Because this was a copy, release it now that we don't need it anymore
        [directoryContents release];
        
        // Return our bytes encapsulated in NSData responsible for freeing them
        return [NSData dataWithBytesNoCopy:bytes length:totalBytesSize freeWhenDone:YES];
    }
}

- (void)saveDocumentImmediately {
    // Just pass the autosave command
    [document shouldAutosaveImmediately];
}

- (void)callCompletionHandler:(BOOL)success data:(id)data error:(int)error close:(BOOL)close {
    if (completionHandlerBlock != nil) {
        completionHandlerBlock(success, data, error);
        Block_release(completionHandlerBlock);
        completionHandlerBlock = nil;
    }

    if (documentCopyMoveURL != nil) {
        [documentCopyMoveURL release];
        documentCopyMoveURL = nil;
    }
    
    if (documentVersionIdentifier != nil) {
        [documentVersionIdentifier release];
        documentVersionIdentifier = nil;
    }
    
    if (documentVersionsHash != nil) {
        [documentVersionsHash release];
        documentVersionsHash = nil;
    }
 
    if (close)
        [self closeDocumentWithNotification:YES];
}

- (void)checkExistenceWithCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler {
    dispatch_async(managerQueue, ^{
        // Save strategy
        documentStrategy = kCloudDocumentStrategyCheckExistence;
        
        // Save completion handler
        completionHandlerBlock = Block_copy(completionHandler);
        
        // Mark document as processing
        documentState = kCloudDocumentStateProcessing;
        
        // Notify delegate of state change
        if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeState:state:)])
            [self.documentDelegate cloudDocumentManagerDidChangeState:self state:documentState];
        
        // Check wether iCloud is available or not
        if ([self isCloudAvailable]) {
            // If iCloud is available, look if this document exists in iCloud
            // Mark document as ubiquitous
            documentIsUbiquitous = YES;
            
            // Close any open document
            [self closeDocumentWithNotification:NO];
            
            if (!documentIsDirectory)
            {
                [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K LIKE %@", NSMetadataItemPathKey, [documentCloudURL path]]];
                [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
            } else {
                [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K BEGINSWITH %@", NSMetadataItemPathKey, [documentCloudURL path]]];
                [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
            }
            
            // Start timeout timer
            [self startQueryTimeoutTimer];
        } else {
            // If iCloud isn't available, just check for local document
            // Mark document as non ubiquitous
            documentIsUbiquitous = NO;
            
            // Close any open document
            [self closeDocumentWithNotification:NO];
            
            // Attempt to acquire local document
            document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentLocalURL] : [[JCPDocument alloc] initWithFileURL:documentLocalURL]);
            if (document == nil) // Close document on failure
                return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
            
            // Check if file already exists
            int error;
            BOOL exists = [document existsWithError:&error];
            
            if (error == kCloudDocumentErrorNone)
                [self callCompletionHandler:YES data:[NSNumber numberWithBool:exists] error:kCloudDocumentErrorNone close:YES];
            else
                [self callCompletionHandler:NO data:nil error:error close:YES];
        }
    });
}

- (void)getModificationDateWithCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler {
    dispatch_async(managerQueue, ^{
        // Save strategy
        documentStrategy = kCloudDocumentStrategyGetModificationDate;
        
        // Save completion handler
        completionHandlerBlock = Block_copy(completionHandler);
        
        // Mark document as processing
        documentState = kCloudDocumentStateProcessing;
        
        // Notify delegate of state change
        if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeState:state:)])
            [self.documentDelegate cloudDocumentManagerDidChangeState:self state:documentState];
        
        // Check wether iCloud is available or not
        if ([self isCloudAvailable]) {
            // If iCloud is available, get cloud modification date
            // Mark document as ubiquitous
            documentIsUbiquitous = YES;
            
            // Close any open document
            [self closeDocumentWithNotification:NO];
            
            if (!documentIsDirectory)
            {
                // Metadata query
                [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K LIKE %@", NSMetadataItemFSNameKey, documentPath]];
                [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
                
                // Start timeout timer
                [self startQueryTimeoutTimer];
            } else {
                // Directory cannot be queried from NSMetadataQuery
                
                // Attempt to acquire cloud document
                document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentCloudURL] : [[JCPDocument alloc] initWithFileURL:documentCloudURL]);
                if (document == nil) // Close document on failure
                    return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
                
                int error;
                BOOL exists = [document existsWithError:&error];
                
                if (error == kCloudDocumentErrorNone) {
                    if (exists) {
                        // Call our completion handler
                        NSDate *modificationDate = [document modificationDate];
                        [self callCompletionHandler:(modificationDate != nil) data:modificationDate error:(modificationDate != nil ? kCloudDocumentErrorNone : kCloudDocumentErrorNativeError) close:YES];
                        
                        return;
                    } else {
                        // Close any open document
                        [self closeDocumentWithNotification:NO];
                        
                        // Attempt to acquire local document
                        document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentLocalURL] : [[JCPDocument alloc] initWithFileURL:documentLocalURL]);
                        if (document == nil) // Close document on failure
                            return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
                        
                        // Check if file already exists
                        exists = [document existsWithError:&error];
                        
                        if (error == kCloudDocumentErrorNone) {
                            if (exists) {
                                // Attempt to render document ubiquitous
                                [document moveDocumentToURL:documentCloudURL overwrite:YES error:nil];
                                
                                // Call our completion handler
                                NSDate *modificationDate = [document modificationDate];
                                [self callCompletionHandler:(modificationDate != nil) data:modificationDate error:(modificationDate != nil ? kCloudDocumentErrorNone : kCloudDocumentErrorNativeError) close:YES];
                                
                                return;
                            } else {
                                // File does not exist at all, call our completion handler!
                                [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorDocumentNotFound close:YES];
                                
                                return;
                            }
                        }
                    }
                }
                
                // If we reach that point we've errored on document exists
                [self callCompletionHandler:NO data:nil error:error close:YES];
            }
        } else {
            // If iCloud isn't available, get local modification date
            // Mark document as non ubiquitous
            documentIsUbiquitous = NO;
            
            // Close any open document
            [self closeDocumentWithNotification:NO];
            
            // Attempt to acquire local document
            document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentLocalURL] : [[JCPDocument alloc] initWithFileURL:documentLocalURL]);
            if (document == nil) // Close document on failure
                return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
            
            // Check if file already exists
            int error;
            BOOL exists = [document existsWithError:&error];
            
            if (error == kCloudDocumentErrorNone) {
                if (exists) {
                    // Call our completion handler
                    NSDate *modificationDate = [document modificationDate];
                    [self callCompletionHandler:(modificationDate != nil) data:modificationDate error:(modificationDate != nil ? kCloudDocumentErrorNone : kCloudDocumentErrorNativeError) close:YES];
                } else {
                    // File does not exist at all, call our completion handler!
                    [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorDocumentNotFound close:YES];
                }
            } else {
                [self callCompletionHandler:NO data:nil error:error close:YES];
            }
        }
    });
}

- (void)copyToPath:(NSString *)destinationPath overwrite:(BOOL)overwrite withCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler {
    dispatch_async(managerQueue, ^{
        // Save strategy
        documentStrategy = kCloudDocumentStrategyCopy;
        
        // Mark document as processing
        documentState = kCloudDocumentStateProcessing;
        
        // Save completion handler
        completionHandlerBlock = Block_copy(completionHandler);
        
        // Notify delegate of state change
        if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeState:state:)])
            [self.documentDelegate cloudDocumentManagerDidChangeState:self state:documentState];
        
        // Check wether iCloud is available or not
        if ([self isCloudAvailable]) {
            // If iCloud is available, look if this document exists in iCloud
            // Mark document as ubiquitous
            documentIsUbiquitous = YES;
            
            // Close any open document
            [self closeDocumentWithNotification:NO];
            
            // Attempt to acquire cloud document
            document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentCloudURL] : [[JCPDocument alloc] initWithFileURL:documentCloudURL]);
            if (document == nil) // Close document on failure
                return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
            
            // File has been moved to iCloud, attempt to copy to destination URL
            [documentCopyMoveURL release];
            documentCopyMoveURL = [[self.urlForUbiquityContainerIdentifier URLByAppendingPathComponent:destinationPath isDirectory:documentIsDirectory] retain];
            documentCopyMoveOverwrite = overwrite;
            
            if (!documentIsDirectory)
            {
                [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K LIKE %@", NSMetadataItemPathKey, [documentCloudURL path]]];
                [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
            } else {
                [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K BEGINSWITH %@", NSMetadataItemPathKey, [documentCloudURL path]]];
                [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
            }
            
            // Start timeout timer
            [self startQueryTimeoutTimer];
        } else {
            // If iCloud isn't available, just check for local document
            // Mark document as non ubiquitous
            documentIsUbiquitous = NO;
            
            // Close any open document
            [self closeDocumentWithNotification:NO];
            
            // Attempt to acquire local document
            document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentLocalURL] : [[JCPDocument alloc] initWithFileURL:documentLocalURL]);
            if (document == nil) // Close document on failure
                return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
            
            // Check if file already exists
            int error;
            BOOL exists = [document existsWithError:&error];
            
            if (error == kCloudDocumentErrorNone) {
                if (exists) {
                    // Attempt to copy to destination URL
                    NSURL *destinationURL = [self.documentsDirectoryURL URLByAppendingPathComponent:destinationPath isDirectory:documentIsDirectory];
                    
                    // Call our completion handler with our result!
                    BOOL success = [document copyDocumentToURL:destinationURL overwrite:overwrite error:&error];
                    [self callCompletionHandler:success data:nil error:error close:YES];
                } else {
                    // Call our completion handler
                    [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorDocumentNotFound close:YES];
                }
            } else {
                // Call our completion handler
                [self callCompletionHandler:NO data:nil error:error close:YES];
            }
        }
    });
}

- (void)moveToPath:(NSString *)destinationPath overwrite:(BOOL)overwrite withCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler {
    dispatch_async(managerQueue, ^{
        // Save strategy
        documentStrategy = kCloudDocumentStrategyMove;
        
        // Mark document as processing
        documentState = kCloudDocumentStateProcessing;
        
        // Save completion handler
        completionHandlerBlock = Block_copy(completionHandler);
        
        // Notify delegate of state change
        if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeState:state:)])
            [self.documentDelegate cloudDocumentManagerDidChangeState:self state:documentState];
        
        
        // Check wether iCloud is available or not
        if ([self isCloudAvailable]) {
            // If iCloud is available, look if this document exists in iCloud
            // Mark document as ubiquitous
            documentIsUbiquitous = YES;
            
            // Close any open document
            [self closeDocumentWithNotification:NO];
            
            // Attempt to acquire cloud document
            document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentCloudURL] : [[JCPDocument alloc] initWithFileURL:documentCloudURL]);
            if (document == nil) // Close document on failure
                return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
            
            // File has been moved to iCloud, attempt to copy to destination URL
            [documentCopyMoveURL release];
            documentCopyMoveURL = [[self.urlForUbiquityContainerIdentifier URLByAppendingPathComponent:destinationPath isDirectory:documentIsDirectory] retain];
            documentCopyMoveOverwrite = overwrite;
            
            if (!documentIsDirectory)
            {
                [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K LIKE %@", NSMetadataItemPathKey, [documentCloudURL path]]];
                [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
            } else {
                [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K BEGINSWITH %@", NSMetadataItemPathKey, [documentCloudURL path]]];
                [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
            }
            
            // Start timeout timer
            [self startQueryTimeoutTimer];
        } else {
            // If iCloud isn't available, just check for local document
            // Mark document as non ubiquitous
            documentIsUbiquitous = NO;
            
            // Close any open document
            [self closeDocumentWithNotification:NO];
            
            // Attempt to acquire local document
            document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentLocalURL] : [[JCPDocument alloc] initWithFileURL:documentLocalURL]);
            if (document == nil) // Close document on failure
                return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
            
            // Check if file already exists
            int error;
            BOOL exists = [document existsWithError:&error];
            
            if (error == kCloudDocumentErrorNone) {
                if (exists) {
                    // Attempt to move to destination URL
                    NSURL *destinationURL = [self.documentsDirectoryURL URLByAppendingPathComponent:destinationPath isDirectory:documentIsDirectory];
                    
                    // Call our completion handler with our result!
                    BOOL success = [document moveDocumentToURL:destinationURL overwrite:overwrite error:&error];
                    [self callCompletionHandler:success data:nil error:error close:YES];
                } else {
                    // Call our completion handler
                    [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorDocumentNotFound close:YES];
                }
            } else {
                // Call our completion handler
                [self callCompletionHandler:NO data:nil error:error close:YES];
            }
        }
    });
}

- (void)getHasConflictVersionsWithCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler {
    dispatch_async(managerQueue, ^{
        // Save strategy
        documentStrategy = kCloudDocumentStrategyHasConflictVersions;
        
        // Save completion handler
        completionHandlerBlock = Block_copy(completionHandler);
        
        // Mark document as processing
        documentState = kCloudDocumentStateProcessing;
        
        // Notify delegate of state change
        if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeState:state:)])
            [self.documentDelegate cloudDocumentManagerDidChangeState:self state:documentState];
        
        // Check it's not a directory
        if (documentIsDirectory) {
            [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
            return;
        }
        
        // Check wether iCloud is available or not
        int error = kCloudDocumentErrorPluginError;
        if ([self isCloudAvailable]) {
            // Mark document as ubiquitous
            documentIsUbiquitous = YES;
            
            // Close any open document
            [self closeDocumentWithNotification:NO];
            
            // Attempt to acquire cloud document
            document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentCloudURL] : [[JCPDocument alloc] initWithFileURL:documentCloudURL]);
            if (document == nil) // Close document on failure
                return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
            
            // Check if document exists
            [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K LIKE %@", NSMetadataItemPathKey, [documentCloudURL path]]];
            [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
            
            // Start timeout timer
            [self startQueryTimeoutTimer];
            
            return;
        } else {
            error = kCloudDocumentErrorCloudUnavailable;
        }
        
        // If we got this far, we failed
        
        // Call our completion handler
        [self callCompletionHandler:NO data:nil error:error close:YES];
    });
}

- (void)getAllVersionsWithCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler {
    dispatch_async(managerQueue, ^{
        // Save strategy
        documentStrategy = kCloudDocumentStrategyGetAllVersions;
        
        // Save completion handler
        completionHandlerBlock = Block_copy(completionHandler);
        
        // Mark document as processing
        documentState = kCloudDocumentStateProcessing;
        
        // Notify delegate of state change
        if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeState:state:)])
            [self.documentDelegate cloudDocumentManagerDidChangeState:self state:documentState];
        
        // Check it's not a directory
        if (documentIsDirectory) {
            [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
            return;
        }
        
        // Check wether iCloud is available or not
        int error = kCloudDocumentErrorPluginError;
        if ([self isCloudAvailable]) {
            // Mark document as ubiquitous
            documentIsUbiquitous = YES;
            
            // Close any open document
            [self closeDocumentWithNotification:NO];
            
            // Attempt to acquire cloud document
            document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentCloudURL] : [[JCPDocument alloc] initWithFileURL:documentCloudURL]);
            if (document == nil) // Close document on failure
                return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
            
            // Check if document exists
            [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K LIKE %@", NSMetadataItemPathKey, [documentCloudURL path]]];
            [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
            
            // Start timeout timer
            [self startQueryTimeoutTimer];
            
            return;
        } else {
            error = kCloudDocumentErrorCloudUnavailable;
        }
        
        // If we got this far, we failed
        
        // Call our completion handler
        [self callCompletionHandler:NO data:nil error:error close:YES];
    });
}

- (void)openDocumentWithVersionIdentifier:(NSData *)versionIdentifier completionHandler:(void (^)(BOOL success, id data, int error))completionHandler {
    dispatch_async(managerQueue, ^{
        // Mark document as processing and strategy as open only
        documentState = kCloudDocumentStateProcessing;
        documentStrategy = kCloudDocumentStrategyOpenVersion;
        
        // Notify delegate of state change
        if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeState:state:)])
            [self.documentDelegate cloudDocumentManagerDidChangeState:self state:documentState];
        
        // Save completion handler
        completionHandlerBlock = Block_copy(completionHandler);
        
        // Check it's not a directory
        if (documentIsDirectory) {
            [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
            return;
        }
        
        // Check wether iCloud is available or not
        int error = kCloudDocumentErrorPluginError;
        if ([self isCloudAvailable]) {
            // Mark document as ubiquitous
            documentIsUbiquitous = YES;
            
            // Close any open document
            [self closeDocumentWithNotification:NO];
            
            // Attempt to acquire cloud document
            document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentCloudURL] : [[JCPDocument alloc] initWithFileURL:documentCloudURL]);
            if (document == nil) // Close document on failure
                return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
            
            // Save version identifier
            [documentVersionIdentifier release];
            documentVersionIdentifier = [versionIdentifier retain];
            
            // Check if document exists
            [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K LIKE %@", NSMetadataItemPathKey, [documentCloudURL path]]];
            [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
            
            // Start timeout timer
            [self startQueryTimeoutTimer];
            
            return;
        } else {
            error = kCloudDocumentErrorCloudUnavailable;
        }
        
        // If we got this far, we failed
        
        // Call our completion handler
        [self callCompletionHandler:NO data:nil error:error close:YES];
    });
}

- (void)pickDocumentWithVersionIdentifier:(NSData *)versionIdentifier versionsHash:(NSString *)md5Hash completionHandler:(void (^)(BOOL success, id data, int error))completionHandler {
    dispatch_async(managerQueue, ^{
        // Mark document as processing and strategy as pick version
        documentState = kCloudDocumentStateProcessing;
        documentStrategy = kCloudDocumentStrategyPickVersion;
        
        // Notify delegate of state change
        if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeState:state:)])
            [self.documentDelegate cloudDocumentManagerDidChangeState:self state:documentState];
        
        // Save completion handler
        completionHandlerBlock = Block_copy(completionHandler);
        
        // Check it's not a directory
        if (documentIsDirectory) {
            [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
            return;
        }
        
        // Check wether iCloud is available or not
        int error = kCloudDocumentErrorPluginError;
        if ([self isCloudAvailable]) {
            // Mark document as ubiquitous
            documentIsUbiquitous = YES;
            
            // Close any open document
            [self closeDocumentWithNotification:NO];
            
            // Attempt to acquire cloud document
            document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentCloudURL] : [[JCPDocument alloc] initWithFileURL:documentCloudURL]);
            if (document == nil) // Close document on failure
                return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
            
            // Save version identifier
            [documentVersionIdentifier release];
            documentVersionIdentifier = [versionIdentifier retain];
            
            // Save versions hash
            [documentVersionsHash release];
            documentVersionsHash = [md5Hash retain];
            
            // Check if document exists
            [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K LIKE %@", NSMetadataItemPathKey, [documentCloudURL path]]];
            [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
            
            // Start timeout timer
            [self startQueryTimeoutTimer];
            
            return;
        } else {
            error = kCloudDocumentErrorCloudUnavailable;
        }
        
        // If we got this far, we failed
        
        // Call our completion handler
        [self callCompletionHandler:NO data:nil error:error close:YES];
    });
}


////////////////////////////////////////////
// Internal Document Manipulation Methods //
////////////////////////////////////////////

#pragma mark Internal Document Manipulation Methods

- (void)createOrOpenCloudDocument {
    // Mark document as ubiquitous
    documentIsUbiquitous = YES;
    
    // Close any open document
    [self closeDocumentWithNotification:NO];
    
    // Attempt to acquire cloud document
    document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentCloudURL] : [[JCPDocument alloc] initWithFileURL:documentCloudURL]);
    if (document == nil) // Close document on failure
        return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
    
    // Check if document exists
    if (!documentIsDirectory)
    {
        [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K LIKE %@", NSMetadataItemPathKey, [documentCloudURL path]]];
        [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
    } else {
        [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K BEGINSWITH %@", NSMetadataItemPathKey, [documentCloudURL path]]];
        [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
    }
    
    // Start timeout timer
    [self startQueryTimeoutTimer];
}

- (void)createOrOpenLocalDocument {
    // Mark document as non ubiquitous
    documentIsUbiquitous = NO;
    
    // Close any open document
    [self closeDocumentWithNotification:NO];
    
    // Attempt to acquire local document
    document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentLocalURL] : [[JCPDocument alloc] initWithFileURL:documentLocalURL]);
    if (document == nil) // Close document on failure
        return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
    
    // Register for document state changed notifications
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(documentStateChangedNotification:) name:JCPDocumentStateChangedNotification object:document];
    
    // Check if file already exists
    int error;
    BOOL exists = [document existsWithError:&error];
    
    if (error == kCloudDocumentErrorNone) {
        if (exists) {
            // File already exists, open it
            if (![document openDocument]) { // Close document on failure
                [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorNativeError close:YES];
            } else {
                [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:NO];
            }
        } else {
            // What's our strategy here ?
            if (documentStrategy == kCloudDocumentStrategyCreateOrOpen) { // are we ok to create the file ?
                if (![document saveDocument]) { // Close document on failure
                    [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorNativeError close:YES];
                } else {
                    [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:NO];
                }
            } else if (documentStrategy == kCloudDocumentStrategyOpen) { // or we are just here for opening existing files ?
                // File doesn't exist
                [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorDocumentNotFound close:YES];
            }
        }
    } else {
        [self callCompletionHandler:NO data:nil error:error close:YES];
    }
}

- (void)createCloudDocument {
    // Mark document as ubiquitous
    documentIsUbiquitous = YES;
    
    // Close any open document
    [self closeDocumentWithNotification:NO];
    
    // Attempt to acquire cloud document
    document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentCloudURL] : [[JCPDocument alloc] initWithFileURL:documentCloudURL]);
    if (document == nil) // Close document on failure
        return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
    
    // Register for document state changed notifications
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(documentStateChangedNotification:) name:JCPDocumentStateChangedNotification object:document];
    
    // Check if document exists
    if (!documentIsDirectory)
    {
        [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K LIKE %@", NSMetadataItemPathKey, [documentCloudURL path]]];
        [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
    } else {
        [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K BEGINSWITH %@", NSMetadataItemPathKey, [documentCloudURL path]]];
        [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
    }
    
    // Start timeout timer
    [self startQueryTimeoutTimer];
}

- (void)createLocalDocument {
    // Mark document as non ubiquitous
    documentIsUbiquitous = NO;
    
    // Close any open document
    [self closeDocumentWithNotification:NO];
    
    // Attempt to acquire local document
    document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentLocalURL] : [[JCPDocument alloc] initWithFileURL:documentLocalURL]);
    if (document == nil) // Close document on failure
        return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
    
    // Register for document state changed notifications
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(documentStateChangedNotification:) name:JCPDocumentStateChangedNotification object:document];
    
    // Check if file already exists
    int error;
    BOOL exists = [document existsWithError:&error];
    
    if (error == kCloudDocumentErrorNone) {
        if (exists) {
            // File already exists, return success
            [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:NO];
        } else {
            // What's our strategy here ?
            if (![document saveDocument]) { // Close document on failure
                [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorNativeError close:YES];
            } else {
                [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:NO];
            }
        }
    } else {
        [self callCompletionHandler:NO data:nil error:error close:YES];
    }
}

- (void)deleteCloudDocument {
    // Mark document as ubiquitous
    documentIsUbiquitous = YES;
    
    // Close any open document
    [self closeDocumentWithNotification:NO];
    
    // Attempt to acquire cloud document
    document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentCloudURL] : [[JCPDocument alloc] initWithFileURL:documentCloudURL]);
    if (document == nil) // Close document on failure
        return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
    
    // Check if document exists
    if (!documentIsDirectory)
    {
        [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K LIKE %@", NSMetadataItemPathKey, [documentCloudURL path]]];
        [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
    } else {
        [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K BEGINSWITH %@", NSMetadataItemPathKey, [documentCloudURL path]]];
        [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
    }
    
    // Start timeout timer
    [self startQueryTimeoutTimer];
}

- (void)deleteLocalDocument {
    // Mark document as non ubiquitous
    documentIsUbiquitous = NO;
    
    // Close any open document
    [self closeDocumentWithNotification:NO];
    
    // Attempt to acquire local document
    document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentLocalURL] : [[JCPDocument alloc] initWithFileURL:documentLocalURL]);
    if (document == nil) // Close document on failure
        return [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
    
    // Check if file already exists
    int error;
    BOOL exists = [document existsWithError:&error];
    
    if (error == kCloudDocumentErrorNone) {
        if (exists) {
            // File exists, delete it
            BOOL success = [document deleteDocument];
            [self callCompletionHandler:YES data:[NSNumber numberWithBool:success] error:(success ? kCloudDocumentErrorNone : kCloudDocumentErrorNativeError) close:YES];
        } else {
            // File doesn't exist
            [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorDocumentNotFound close:YES];
        }
    } else {
        [self callCompletionHandler:NO data:nil error:error close:YES];
    }
}

- (void)closeDocumentWithNotification:(BOOL)notification {
    // Failsafe
    if (document == nil)
        return;
    
    // Close document
    [document closeDocument];
    [document release];
    document = nil;
    
    // Notify on our end
    [[NSNotificationCenter defaultCenter] removeObserver:self name:JCPDocumentStateChangedNotification object:document];
    documentState = kCloudDocumentStateClosed;
    
    // Notify delegate of state change if asked by caller
    if (notification && self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeState:state:)])
        [self.documentDelegate cloudDocumentManagerDidChangeState:self state:documentState];
}

- (void)startQueryTimeoutTimer {
    [documentTimeoutQueryTime release];
    documentTimeoutQueryTime = [[NSDate date] retain];
    
    // Create a timer that will periodically check for failure
    if (documentTimeoutTimer != nil) {
        dispatch_source_cancel(documentTimeoutTimer);
        dispatch_release(documentTimeoutTimer);
    }
    documentTimeoutTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, managerQueue);
    
    // Prepare a 100ms timer with 10ms leeway
    dispatch_source_set_timer(documentTimeoutTimer, dispatch_walltime(NULL, 300ull * NSEC_PER_MSEC), 300ull * NSEC_PER_MSEC, 100ull * NSEC_PER_MSEC);
    
    //__block id unretained_self = self;
    dispatch_source_set_event_handler(documentTimeoutTimer, ^(void) {
        BOOL stopTimer = NO;
        
        if (documentTimeoutQueryTime != nil) {
            // Did we fail?
            if ([[NSDate date] timeIntervalSinceDate:documentTimeoutQueryTime] > 15) {
                // Stop querying
                if (metadataQuery != nil) {
                    [metadataQuery disableUpdates];
                    [metadataQuery stopQuery];
                    [metadataQuery release];
                    metadataQuery = [[NSMetadataQuery alloc] init];
                    [metadataQuery setSearchScopes:[NSArray arrayWithObject:NSMetadataQueryUbiquitousDocumentsScope]];
                }
                
                // Return failure
                [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorPluginError close:YES];
                
                // Stop the timer
                stopTimer = YES;
            }
        } else {
            stopTimer = YES;
        }
        
        if (stopTimer) {
            // Release time
            [documentTimeoutQueryTime release];
            documentTimeoutQueryTime = nil;
            
            // Cancel and release timer
            dispatch_source_cancel(documentTimeoutTimer);
            dispatch_release(documentTimeoutTimer);
            documentTimeoutTimer = nil;
        }
    });
    
    // Fire timer
    dispatch_resume(documentTimeoutTimer);
}

- (void)stopQueryTimeoutTimer {
    [documentTimeoutQueryTime release];
    documentTimeoutQueryTime = nil;
    if (documentTimeoutTimer != nil) {
        dispatch_source_cancel(documentTimeoutTimer);
        dispatch_release(documentTimeoutTimer);
        documentTimeoutTimer = nil;
    }
}


- (void)startDownloadTimeoutTimer {
    [documentTimeoutDownloadTime release];
    documentTimeoutDownloadTime = [[NSDate date] retain];
    
    // Create a timer that will periodically check for failure
    if (documentTimeoutTimer != nil) {
        dispatch_source_cancel(documentTimeoutTimer);
        dispatch_release(documentTimeoutTimer);
    }
    documentTimeoutTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, managerQueue);
    
    // Prepare a 300ms timer with 100ms leeway
    dispatch_source_set_timer(documentTimeoutTimer, dispatch_walltime(NULL, 300ull * NSEC_PER_MSEC), 300ull * NSEC_PER_MSEC, 100ull * NSEC_PER_MSEC);
    dispatch_source_set_event_handler(documentTimeoutTimer, ^(void) {
        BOOL stopTimer = NO;
        
        if (documentTimeoutDownloadTime != nil) {
            // Did we fail?
            if ([[NSDate date] timeIntervalSinceDate:documentTimeoutDownloadTime] > 15) {
                // Stop querying
                if (metadataQuery != nil) {
                    [metadataQuery disableUpdates];
                    [metadataQuery stopQuery];
                    [metadataQuery release];
                    metadataQuery = [[NSMetadataQuery alloc] init];
                    [metadataQuery setSearchScopes:[NSArray arrayWithObject:NSMetadataQueryUbiquitousDocumentsScope]];
                }
                
                // Return failure
                [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorDownloadTimeout close:YES];
                
                // Stop the timer
                stopTimer = YES;
            }
        } else {
            stopTimer = YES;
        }
        
        if (stopTimer) {
            // Release time
            [documentTimeoutDownloadTime release];
            documentTimeoutDownloadTime = nil;
            
            // Cancel and release timer
            dispatch_source_cancel(documentTimeoutTimer);
            dispatch_release(documentTimeoutTimer);
            documentTimeoutTimer = nil;
        }
    });
    
    // Fire timer
    dispatch_resume(documentTimeoutTimer);
}

- (void)stopDownloadTimeoutTimer {
    [documentTimeoutDownloadTime release];
    documentTimeoutDownloadTime = nil;
    if (documentTimeoutTimer != nil) {
        dispatch_source_cancel(documentTimeoutTimer);
        dispatch_release(documentTimeoutTimer);
        documentTimeoutTimer = nil;
    }
}


////////////////////////////////////////////
// NSMetadataQuery Notifications Handling //
////////////////////////////////////////////

#pragma mark NSMetadataQuery Notifications Handling

- (void)metadataQueryDidStartGatheringNotification:(NSNotification *)notification {
    // Process results on another thread
    dispatch_async(managerQueue, ^{
        NSMetadataQuery *query = [notification object];
        if (query != metadataQuery)
            return;
        
        // Metadata started, update timeout
        [documentTimeoutQueryTime release];
        documentTimeoutQueryTime = [[NSDate date] retain];
    });
}


- (void)metadataQueryGatheringProgressNotification:(NSNotification *)notification {
    // Process results on another thread
    dispatch_async(managerQueue, ^{
        NSMetadataQuery *query = [notification object];
        if (query != metadataQuery)
            return;
        
        // Metadata is making progress, update timeout
        [documentTimeoutQueryTime release];
        documentTimeoutQueryTime = [[NSDate date] retain];
    });
}

- (void)metadataQueryDidFinishGatheringNotification:(NSNotification *)notification {
    // Process results on another thread
    dispatch_async(managerQueue, ^{
        NSMetadataQuery *query = [notification object];
        if (query != metadataQuery)
            return;
        
        // Stop timeout timer
        [self stopQueryTimeoutTimer];
        
        NSArray *results = [metadataQuery results];
        
        switch (documentStrategy) {
            case kCloudDocumentStrategyCreateOrOpen:
            case kCloudDocumentStrategyOpen: {
                // Check if file already exists
                if ([results count] != 0) { // File already exists in iCloud
                    if (!documentIsDirectory) {
                        NSMetadataItem *documentItem = [[metadataQuery results] lastObject];
                        
                        if ([[documentItem valueForAttribute:NSMetadataUbiquitousItemIsDownloadedKey] boolValue])
                        {
                            // Stop querying
                            [metadataQuery disableUpdates];
                            [metadataQuery stopQuery];
                            
                            // Register for document state changed notifications
                            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(documentStateChangedNotification:) name:JCPDocumentStateChangedNotification object:document];
                            
                            // File already exists, open it
                            if (![document openDocument]) { // Close document on failure
                                [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorNativeError close:YES];
                            } else {
                                [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:NO];
                            }
                        } else {
                            if (![[documentItem valueForAttribute:NSMetadataUbiquitousItemIsDownloadingKey] boolValue])
                                [[[[NSFileManager alloc] init] autorelease] startDownloadingUbiquitousItemAtURL:documentCloudURL error:nil];
                            
                            // Start a timer to prevent stalled downloads
                            documentLastProgress = 0.0f;
                            [self startDownloadTimeoutTimer];
                        }
                    } else {
                        // Register for document state changed notifications
                        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(documentStateChangedNotification:) name:JCPDocumentStateChangedNotification object:document];
                        
                        // Stop querying
                        [metadataQuery disableUpdates];
                        [metadataQuery stopQuery];
                        
                        // File already exists, open it
                        if (![document openDocument]) { // Close document on failure
                            [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorNativeError close:YES];
                        } else {
                            [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:NO];
                        }
                    }
                } else { // File is not in iCloud
                    // Stop querying
                    [metadataQuery disableUpdates];
                    [metadataQuery stopQuery];
                    
                    if (documentIsDirectory) {
                        // Directory may exist but have no file -- hence the failed query
                        // Close any open document
                        [self closeDocumentWithNotification:NO];
                        
                        // Attempt to acquire cloud document
                        document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentCloudURL] : [[JCPDocument alloc] initWithFileURL:documentCloudURL]);
                        if (document == nil) { // Close document on failure
                            [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
                            break;
                        }
                        
                        // Check existence
                        int error;
                        BOOL exists = [document existsWithError:&error];
                        
                        if (error == kCloudDocumentErrorNone) {
                            if (exists) {
                                // Register for document state changed notifications
                                [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(documentStateChangedNotification:) name:JCPDocumentStateChangedNotification object:document];
                                
                                if (![document openDocument]) { // Close document on failure
                                    [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorNativeError close:YES];
                                } else {
                                    [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:NO];
                                }
                                break;
                            }
                        } else {
                            [self callCompletionHandler:NO data:nil error:error close:YES];
                            break;
                        }
                    }
                    
                    // Close any open document
                    [self closeDocumentWithNotification:NO];
                    
                    // Attempt to acquire local document
                    document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentLocalURL] : [[JCPDocument alloc] initWithFileURL:documentLocalURL]);
                    if (document == nil) { // Close document on failure
                        [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
                        break;
                    }
                    
                    // Check if file already exists
                    int error;
                    BOOL exists = [document existsWithError:&error];
                    
                    if (error == kCloudDocumentErrorNone) {
                        if (exists) {
                            // Register for document state changed notifications
                            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(documentStateChangedNotification:) name:JCPDocumentStateChangedNotification object:document];
                            
                            // File already exists, open it
                            if ([document openDocument]) {
                                // Attempt to render document ubiquitous
                                if (![document moveDocumentToURL:documentCloudURL overwrite:YES error:nil]) { // close document if failure
                                    [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorNativeError close:YES];
                                } else {
                                    [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:NO];
                                }
                            } else { // Close document if failure
                                [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorNativeError close:YES];
                            }
                        } else {
                            // What's our strategy here ?
                            if (documentStrategy == kCloudDocumentStrategyCreateOrOpen) { // If we are trying to create or open, create file
                                // Close any open document
                                [self closeDocumentWithNotification:NO];
                                
                                // Attempt to acquire cloud document again
                                document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentCloudURL] : [[JCPDocument alloc] initWithFileURL:documentCloudURL]);
                                if (document == nil) { // Close document on failure
                                    [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
                                    break;
                                }
                                
                                // Register for document state changed notifications
                                [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(documentStateChangedNotification:) name:JCPDocumentStateChangedNotification object:document];
                                
                                // File doesn't exist yet, create it
                                if (![document saveDocument]) { // Close document on failure
                                    [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorNativeError close:YES];
                                } else {
                                    [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:NO];
                                }
                            } else { // If we are on open only, notify file does not exist
                                // File doesn't exists
                                [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorDocumentNotFound close:YES];
                            }
                        }
                    } else {
                        [self callCompletionHandler:NO data:nil error:error close:YES];
                    }
                }
                
                break;
            }
            case kCloudDocumentStrategyCreate: {
                // Stop querying
                [metadataQuery disableUpdates];
                [metadataQuery stopQuery];
                
                if ([results count] != 0) { // File already exists in iCloud
                    // Return success
                    [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:NO];
                } else {
                    if (documentIsDirectory) {
                        // Directory may exist but have no file -- hence the failed query
                        
                        // Check existence
                        int error;
                        BOOL exists = [document existsWithError:&error];
                        
                        if (error == kCloudDocumentErrorNone) {
                            if (exists) {
                                // Directory exists, success
                                [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:NO];
                                break;
                            }
                        } else {
                            [self callCompletionHandler:NO data:nil error:error close:YES];
                            break;
                        }
                    }
                    
                    // Close any open document
                    [self closeDocumentWithNotification:NO];
                    
                    // Attempt to acquire local document
                    document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentLocalURL] : [[JCPDocument alloc] initWithFileURL:documentLocalURL]);
                    if (document == nil) { // Close document on failure
                        [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
                        break;
                    }
                    
                    // Check if file already exists
                    int error;
                    BOOL exists = [document existsWithError:&error];
                    
                    if (error == kCloudDocumentErrorNone) {
                        if (exists) {
                            // Attempt to render document ubiquitous
                            if (![document moveDocumentToURL:documentCloudURL overwrite:YES error:nil]) { // close document if failure
                                [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorNativeError close:YES];
                            } else {
                                [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:NO];
                            }
                        } else {
                            // Close any open document
                            [self closeDocumentWithNotification:NO];
                            
                            // Attempt to acquire cloud document again
                            document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentCloudURL] : [[JCPDocument alloc] initWithFileURL:documentCloudURL]);
                            if (document == nil) { // Close document on failure
                                [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
                                break;
                            }
                            
                            // File/directory doesn't exist yet, create it
                            if (![document saveDocument]) { // Close document on failure
                                [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorNativeError close:YES];
                            } else {
                                [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:NO];
                            }
                        }
                    } else {
                        [self callCompletionHandler:NO data:nil error:error close:YES];
                    }
                }
                
                break;
            }
            case kCloudDocumentStrategyCheckExistence: {
                // Stop querying
                [metadataQuery disableUpdates];
                [metadataQuery stopQuery];
                
                if ([results count] != 0) {
                    // Trigger a download if file is not downloaded
                    if (!documentIsDirectory) {
                        NSMetadataItem *documentItem = [[metadataQuery results] lastObject];
                        
                        if (![[documentItem valueForAttribute:NSMetadataUbiquitousItemIsDownloadedKey] boolValue])
                        {
                            if (![[documentItem valueForAttribute:NSMetadataUbiquitousItemIsDownloadingKey] boolValue])
                                [[[[NSFileManager alloc] init] autorelease] startDownloadingUbiquitousItemAtURL:documentCloudURL error:nil];
                        }
                    }
                    
                    // File exists in iCloud
                    [self callCompletionHandler:YES data:[NSNumber numberWithBool:YES] error:kCloudDocumentErrorNone close:YES];
                } else {
                    if (documentIsDirectory) {
                        // Directory may exist but have no file -- hence the failed query
                        // Close any open document
                        [self closeDocumentWithNotification:NO];
                        
                        // Attempt to acquire cloud document
                        document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentCloudURL] : [[JCPDocument alloc] initWithFileURL:documentCloudURL]);
                        if (document == nil) { // Close document on failure
                            [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
                            break;
                        }
                        
                        int error;
                        BOOL exists = [document existsWithError:&error];
                        
                        if (error == kCloudDocumentErrorNone) {
                            if (exists) {
                                [self callCompletionHandler:YES data:[NSNumber numberWithBool:YES] error:kCloudDocumentErrorNone close:YES];
                                break;
                            }
                        } else {
                            [self callCompletionHandler:NO data:nil error:error close:YES];
                            break;
                        }
                    }
                    
                    // File does not exist in iCloud
                    // Maybe file is up locally and needs to be pushed to iCloud
                    // Close any open document
                    [self closeDocumentWithNotification:NO];
                    
                    // Attempt to acquire local document
                    document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentLocalURL] : [[JCPDocument alloc] initWithFileURL:documentLocalURL]);
                    if (document == nil) { // Close document on failure
                        [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
                        break;
                    }
                    
                    // Check if file already exists
                    int error;
                    BOOL exists = [document existsWithError:&error];
                    
                    if (error == kCloudDocumentErrorNone) {
                        if (exists) {
                            // Attempt to render document ubiquitous
                            [document moveDocumentToURL:documentCloudURL overwrite:YES error:nil];
                            
                            // File exists and should have been pushed to the cloud, call our completion handler!
                            [self callCompletionHandler:YES data:[NSNumber numberWithBool:YES] error:kCloudDocumentErrorNone close:YES];
                        } else {
                            // File does not exist at all, call our completion handler!
                            [self callCompletionHandler:YES data:[NSNumber numberWithBool:NO] error:kCloudDocumentErrorNone close:YES];
                        }
                    } else {
                        [self callCompletionHandler:NO data:nil error:error close:YES];
                    }
                }
                break;
            }
            case kCloudDocumentStrategyGetModificationDate: {
                // Stop querying
                [metadataQuery disableUpdates];
                [metadataQuery stopQuery];
                
                if ([results count] != 0) { // File already exists in iCloud
                    // Trigger a download if file is not downloaded
                    NSMetadataItem *documentItem = [[metadataQuery results] lastObject];
                    if (!documentIsDirectory) {
                        if (![[documentItem valueForAttribute:NSMetadataUbiquitousItemIsDownloadedKey] boolValue])
                        {
                            if (![[documentItem valueForAttribute:NSMetadataUbiquitousItemIsDownloadingKey] boolValue])
                                [[[[NSFileManager alloc] init] autorelease] startDownloadingUbiquitousItemAtURL:documentCloudURL error:nil];
                        }
                    }
                    
                    NSDate *modificationDate = [documentItem valueForAttribute:NSMetadataItemFSContentChangeDateKey];
                    
                    // Call our completion handler
                    [self callCompletionHandler:YES data:modificationDate error:kCloudDocumentErrorNone close:YES];
                } else { // File is not in iCloud
                    // Close any open document
                    [self closeDocumentWithNotification:NO];
                    
                    // Attempt to acquire local document
                    document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentLocalURL] : [[JCPDocument alloc] initWithFileURL:documentLocalURL]);
                    if (document == nil) { // Close document on failure
                        [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
                        break;
                    }
                    
                    // Check if file already exists
                    int error;
                    BOOL exists = [document existsWithError:&error];
                    
                    if (error == kCloudDocumentErrorNone) {
                        if (exists) {
                            // Attempt to render document ubiquitous
                            [document moveDocumentToURL:documentCloudURL overwrite:YES error:nil];
                            
                            // Call our completion handler
                            NSDate *modificationDate = [document modificationDate];
                            [self callCompletionHandler:(modificationDate != nil) data:modificationDate error:(modificationDate != nil ? kCloudDocumentErrorNone : kCloudDocumentErrorNativeError) close:YES];
                        } else {
                            // File does not exist at all, call our completion handler!
                            [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorDocumentNotFound close:YES];
                        }
                    } else {
                        [self callCompletionHandler:NO data:nil error:error close:YES];
                    }
                }
                
                break;
            }
            case kCloudDocumentStrategyDelete: {
                // Stop querying
                [metadataQuery disableUpdates];
                [metadataQuery stopQuery];
                
                // Check if file already exists
                if ([results count] != 0) {
                    // Delete our document
                    BOOL success = [document deleteDocument];
                    [self callCompletionHandler:YES data:[NSNumber numberWithBool:success] error:(success ? kCloudDocumentErrorNone : kCloudDocumentErrorNativeError) close:YES];
                } else { // File does not exist in iCloud
                    if (documentIsDirectory) {
                        // Directory may exist but have no file -- hence the failed query
                        // Close any open document
                        [self closeDocumentWithNotification:NO];
                        
                        // Attempt to acquire cloud document
                        document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentCloudURL] : [[JCPDocument alloc] initWithFileURL:documentCloudURL]);
                        if (document == nil) { // Close document on failure
                            [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
                            break;
                        }
                        
                        // Check existence
                        int error;
                        BOOL exists = [document existsWithError:&error];
                        
                        if (error == kCloudDocumentErrorNone) {
                            if (exists) {
                                // Delete our document
                                BOOL success = [document deleteDocument];
                                [self callCompletionHandler:YES data:[NSNumber numberWithBool:success] error:(success ? kCloudDocumentErrorNone : kCloudDocumentErrorNativeError) close:YES];
                                break;
                            }
                        } else {
                            [self callCompletionHandler:NO data:nil error:error close:YES];
                            break;
                        }
                    }
                    
                    // Close any open document
                    [self closeDocumentWithNotification:NO];
                    
                    // Attempt to acquire local document
                    document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentLocalURL] : [[JCPDocument alloc] initWithFileURL:documentLocalURL]);
                    if (document == nil) { // Close document on failure
                        [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
                        break;
                    }
                    
                    // Check if file already exists
                    int error;
                    BOOL exists = [document existsWithError:&error];
                    
                    if (error == kCloudDocumentErrorNone) {
                        if (exists) {
                            // Delete our document
                            BOOL success = [document deleteDocument];
                            [self callCompletionHandler:YES data:[NSNumber numberWithBool:success] error:(success ? kCloudDocumentErrorNone : kCloudDocumentErrorNativeError) close:YES];
                        } else {
                            // File doesn't exist
                            [self callCompletionHandler:YES data:[NSNumber numberWithBool:NO] error:kCloudDocumentErrorDocumentNotFound close:YES];
                        }
                    } else {
                        [self callCompletionHandler:NO data:nil error:error close:YES];
                    }
                }
                
                break;
            }
            case kCloudDocumentStrategyCopy:
            case kCloudDocumentStrategyMove: {
                // Check if file already exists
                if ([results count] != 0) {
                    // We have to wait until all files are downloaded before we can copy
                    BOOL hasUndownloadedFiles = NO;
                    for (NSMetadataItem *item in results) {
                        if (![[item valueForAttribute:NSMetadataUbiquitousItemIsDownloadedKey] boolValue])
                        {
                            hasUndownloadedFiles = YES;
                            if (![[item valueForAttribute:NSMetadataUbiquitousItemIsDownloadingKey] boolValue])
                                [[[[NSFileManager alloc] init] autorelease] startDownloadingUbiquitousItemAtURL:[item valueForAttribute:NSMetadataItemURLKey] error:nil];
                        }
                    }
                    
                    if (!hasUndownloadedFiles)
                    {
                        // Call our completion handler with our result!
                        int error;
                        BOOL success;
                        if (documentStrategy == kCloudDocumentStrategyCopy)
                            success = [document copyDocumentToURL:documentCopyMoveURL overwrite:documentCopyMoveOverwrite error:&error];
                        else
                            success = [document moveDocumentToURL:documentCopyMoveURL overwrite:documentCopyMoveOverwrite error:&error];
                        
                        [self callCompletionHandler:success data:nil error:error close:YES];
                        
                        // Stop query
                        [metadataQuery disableUpdates];
                        [metadataQuery stopQuery];
                    } else {
                        // Start a timer to prevent stalled downloads
                        documentLastProgress = 0.0f;
                        [self startDownloadTimeoutTimer];
                    }
                } else {
                    // Stop query
                    [metadataQuery disableUpdates];
                    [metadataQuery stopQuery];
                    
                    if (documentIsDirectory) {
                        // Directory may exist but have no file -- hence the failed query
                        // Close any open document
                        [self closeDocumentWithNotification:NO];
                        
                        // Attempt to acquire cloud document
                        document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentCloudURL] : [[JCPDocument alloc] initWithFileURL:documentCloudURL]);
                        if (document == nil) { // Close document on failure
                            [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
                            break;
                        }
                        
                        // Check existence
                        int error;
                        BOOL exists = [document existsWithError:&error];
                        
                        if (error == kCloudDocumentErrorNone) {
                            if (exists) {
                                // Call our completion handler with our result!
                                BOOL success;
                                if (documentStrategy == kCloudDocumentStrategyCopy)
                                    success = [document copyDocumentToURL:documentCopyMoveURL overwrite:documentCopyMoveOverwrite error:&error];
                                else
                                    success = [document moveDocumentToURL:documentCopyMoveURL overwrite:documentCopyMoveOverwrite error:&error];
                                
                                [self callCompletionHandler:success data:nil error:error close:YES];
                                break;
                            }
                        } else {
                            [self callCompletionHandler:NO data:nil error:error close:YES];
                            break;
                        }
                    }
                    
                    // Maybe file is up locally and needs to be pushed to iCloud
                    // Close any open document
                    [self closeDocumentWithNotification:NO];
                    
                    // Attempt to acquire local document
                    document = (documentIsDirectory ? [[JCPDocument alloc] initWithDirectoryURL:documentLocalURL] : [[JCPDocument alloc] initWithFileURL:documentLocalURL]);
                    if (document == nil) { // Close document on failure
                        [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorInvalidArguments close:YES];
                        break;
                    }
                    
                    // Check if file already exists
                    int error;
                    BOOL exists = [document existsWithError:&error];
                    
                    if (error == kCloudDocumentErrorNone) {
                        if (exists) {
                            // Copy or move?
                            BOOL success;
                            if (documentStrategy == kCloudDocumentStrategyCopy) {
                                // Before copying, try to move to iCloud
                                BOOL ubiquitousSuccess = [document moveDocumentToURL:documentCloudURL overwrite:YES error:nil];
                                if (!ubiquitousSuccess) {
                                    // File couldn't be moved to iCloud, don't bother with copying, call our completion handler!
                                    [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorNativeError close:YES];
                                    break;
                                } else
                                    success = [document copyDocumentToURL:documentCopyMoveURL overwrite:documentCopyMoveOverwrite error:&error];
                            } else // Move operation will also render document ubiquitous... awesome!
                                success = [document moveDocumentToURL:documentCopyMoveURL overwrite:documentCopyMoveOverwrite error:&error];
                            
                            [self callCompletionHandler:success data:nil error:error close:YES];
                            
                        } else {
                            // File does not exist at all, call our completion handler!
                            [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorDocumentNotFound close:YES];
                        }
                    } else {
                        [self callCompletionHandler:NO data:nil error:error close:YES];
                    }
                }
                
                break;
            }
            case kCloudDocumentStrategyHasConflictVersions: {
                // Check if file already exists
                if ([results count] != 0) { // File already exists in iCloud
                    NSMetadataItem *documentItem = [[metadataQuery results] lastObject];
                    
                    if ([[documentItem valueForAttribute:NSMetadataUbiquitousItemIsDownloadedKey] boolValue])
                    {
                        // Stop querying
                        [metadataQuery disableUpdates];
                        [metadataQuery stopQuery];
                        
                        // Fetch versions
                        NSArray *versions = [NSFileVersion unresolvedConflictVersionsOfItemAtURL:documentCloudURL];
                        if (versions != nil && versions.count > 0) { // Conflicts
                            // Call our completion handler
                            [self callCompletionHandler:YES data:[NSNumber numberWithBool:YES] error:kCloudDocumentErrorNone close:YES];
                            
                            break;
                        } else if ([NSFileVersion currentVersionOfItemAtURL:documentCloudURL] != nil) { // Do we even have a current version? If yes that means no conflict
                            // Call our completion handler
                            [self callCompletionHandler:YES data:[NSNumber numberWithBool:NO] error:kCloudDocumentErrorNone close:YES];
                            
                            break;
                        }
                        
                        // We should never get there
                        // Call our completion handler
                        [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorPluginError close:YES];
                    } else {
                        if (![[documentItem valueForAttribute:NSMetadataUbiquitousItemIsDownloadingKey] boolValue])
                            [[[[NSFileManager alloc] init] autorelease] startDownloadingUbiquitousItemAtURL:documentCloudURL error:nil];
                        
                        // Start a timer to prevent stalled downloads
                        documentLastProgress = 0.0f;
                        [self startDownloadTimeoutTimer];
                    }
                } else {
                    // Stop querying
                    [metadataQuery disableUpdates];
                    [metadataQuery stopQuery];
                    
                    // Document may not exist at all or is not in iCloud so it won't have versions
                    
                    // Close any open document
                    [self closeDocumentWithNotification:NO];
                    
                    // Attempt to acquire local document
                    document = [[JCPDocument alloc] initWithFileURL:documentLocalURL];
                    
                    int error;
                    if (document != nil) {
                        // Check if file already exists
                        BOOL exists = [document existsWithError:&error];
                        
                        if (error == kCloudDocumentErrorNone) {
                            if (exists) {
                                // Attempt to render document ubiquitous
                                if ([document moveDocumentToURL:documentCloudURL overwrite:YES error:nil]) {
                                    // Document is now ubiquitous but obviously has no conflicts
                                    [self callCompletionHandler:YES data:[NSNumber numberWithBool:NO] error:kCloudDocumentErrorNone close:YES];
                                    break;
                                } else {
                                    error = kCloudDocumentErrorNativeError;
                                }
                            } else {
                                // File does not exist at all
                                error = kCloudDocumentErrorDocumentNotFound;
                            }
                        }
                    } else {
                        error = kCloudDocumentErrorInvalidArguments;
                    }
                    
                    // If we got this far we failed
                    
                    // Call our completion handler
                    [self callCompletionHandler:NO data:nil error:error close:YES];
                }
                
                break;
            }
            case kCloudDocumentStrategyGetAllVersions: {
                // Check if file already exists
                if ([results count] != 0) { // File already exists in iCloud
                    NSMetadataItem *documentItem = [[metadataQuery results] lastObject];
                    
                    if ([[documentItem valueForAttribute:NSMetadataUbiquitousItemIsDownloadedKey] boolValue])
                    {
                        // Stop querying
                        [metadataQuery disableUpdates];
                        [metadataQuery stopQuery];
                        
                        // Fetch versions
                        NSArray *conflictVersions = [NSFileVersion unresolvedConflictVersionsOfItemAtURL:documentCloudURL];
                        NSFileVersion *currentVersion = [NSFileVersion currentVersionOfItemAtURL:documentCloudURL];
                        
                        if (currentVersion != nil) {
                            NSMutableArray *allVersions = [NSMutableArray arrayWithObject:currentVersion];
                            if (conflictVersions != nil)
                                [allVersions addObjectsFromArray:conflictVersions];
                            
                            // Call our completion handler
                            [self callCompletionHandler:YES data:allVersions error:kCloudDocumentErrorNone close:YES];
                            
                            break;
                        }
                        
                        // We should never get there
                        // Call our completion handler
                        [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorPluginError close:YES];
                    } else {
                        if (![[documentItem valueForAttribute:NSMetadataUbiquitousItemIsDownloadingKey] boolValue])
                            [[[[NSFileManager alloc] init] autorelease] startDownloadingUbiquitousItemAtURL:documentCloudURL error:nil];
                        
                        // Start a timer to prevent stalled downloads
                        documentLastProgress = 0.0f;
                        [self startDownloadTimeoutTimer];
                    }
                } else {
                    // Stop querying
                    [metadataQuery disableUpdates];
                    [metadataQuery stopQuery];
                    
                    // Document may not exist at all or is not in iCloud so it won't have versions
                    
                    // Close any open document
                    [self closeDocumentWithNotification:NO];
                    
                    // Attempt to acquire local document
                    document = [[JCPDocument alloc] initWithFileURL:documentLocalURL];
                    
                    int error;
                    if (document != nil) {
                        // Check if file already exists
                        BOOL exists = [document existsWithError:&error];
                        
                        if (error == kCloudDocumentErrorNone) {
                            if (exists) {
                                // Attempt to render document ubiquitous
                                if ([document moveDocumentToURL:documentCloudURL overwrite:YES error:nil]) {
                                    NSFileVersion *currentVersion = [NSFileVersion currentVersionOfItemAtURL:documentCloudURL];
                                    if (currentVersion != nil) {
                                        // Document is now ubiquitous and current version is the only version
                                        [self callCompletionHandler:YES data:[NSArray arrayWithObject:currentVersion] error:kCloudDocumentErrorNone close:YES];
                                        break;
                                    } else {
                                        error = kCloudDocumentErrorPluginError;
                                    }
                                } else {
                                    error = kCloudDocumentErrorNativeError;
                                }
                            } else {
                                // File does not exist at all
                                error = kCloudDocumentErrorDocumentNotFound;
                            }
                        }
                    } else {
                        error = kCloudDocumentErrorInvalidArguments;
                    }
                    
                    // If we got this far we failed
                    
                    // Call our completion handler
                    [self callCompletionHandler:NO data:nil error:error close:YES];
                }
                
                break;
            }
            case kCloudDocumentStrategyOpenVersion: {
                // Check if file already exists
                if ([results count] != 0) { // File already exists in iCloud
                    NSMetadataItem *documentItem = [[metadataQuery results] lastObject];
                    
                    if ([[documentItem valueForAttribute:NSMetadataUbiquitousItemIsDownloadedKey] boolValue])
                    {
                        // Stop querying
                        [metadataQuery disableUpdates];
                        [metadataQuery stopQuery];
                        
                        // Check if this item version matches
                        int error;
                        
                        NSFileVersion *version = [NSFileVersion versionOfItemAtURL:documentCloudURL forPersistentIdentifier:[NSKeyedUnarchiver unarchiveObjectWithData:documentVersionIdentifier]];
                        [documentVersionIdentifier release];
                        documentVersionIdentifier = nil;
                        
                        if (version != nil) {
                            // Mark document as non ubiquitous
                            documentIsUbiquitous = NO;
                            
                            // Close any open document
                            [self closeDocumentWithNotification:NO];
                            
                            // Attempt to acquire version document
                            document = [[JCPDocument alloc] initWithFileURL:version.URL];
                            if (document != nil) {
                                // Register for document state changed notifications
                                [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(documentStateChangedNotification:) name:JCPDocumentStateChangedNotification object:document];
                                
                                // Check if file already exists
                                BOOL exists = [document existsWithError:&error];
                                
                                if (error == kCloudDocumentErrorNone) {
                                    if (exists) {
                                        // File already exists, open it
                                        if ([document openDocument]) {
                                            [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:NO];
                                            break;
                                        } else {
                                            error = kCloudDocumentErrorNativeError;
                                        }
                                    } else {
                                        error = kCloudDocumentErrorDocumentNotFound;
                                    }
                                }
                            } else {
                                error = kCloudDocumentErrorPluginError;
                            }
                        } else {
                            error = kCloudDocumentErrorInvalidVersionIdentifier;
                        }
                        
                        // If we got this far we failed
                        
                        // Call our completion handler
                        [self callCompletionHandler:NO data:nil error:error close:YES];
                    } else {
                        if (![[documentItem valueForAttribute:NSMetadataUbiquitousItemIsDownloadingKey] boolValue])
                            [[[[NSFileManager alloc] init] autorelease] startDownloadingUbiquitousItemAtURL:documentCloudURL error:nil];
                        
                        // Start a timer to prevent stalled downloads
                        documentLastProgress = 0.0f;
                        [self startDownloadTimeoutTimer];
                    }
                } else {
                    // Stop querying
                    [metadataQuery disableUpdates];
                    [metadataQuery stopQuery];
                    
                    // Document may not exist at all or is not in iCloud so it won't have versions
                    [documentVersionIdentifier release];
                    documentVersionIdentifier = nil;
                    
                    // Close any open document
                    [self closeDocumentWithNotification:NO];
                    
                    // Attempt to acquire local document
                    document = [[JCPDocument alloc] initWithFileURL:documentLocalURL];
                    
                    int error;
                    if (document != nil) {
                        // Check if file already exists
                        BOOL exists = [document existsWithError:&error];
                        
                        if (error == kCloudDocumentErrorNone) {
                            if (exists) {
                                // Attempt to render document ubiquitous
                                if ([document moveDocumentToURL:documentCloudURL overwrite:YES error:nil]) {
                                    // Document is now ubiquitous but obviously there's no way we could have a version number
                                    error = kCloudDocumentErrorInvalidVersionIdentifier;
                                } else {
                                    error = kCloudDocumentErrorNativeError;
                                }
                            } else {
                                // File does not exist at all
                                error = kCloudDocumentErrorDocumentNotFound;
                            }
                        }
                    } else {
                        error = kCloudDocumentErrorInvalidArguments;
                    }
                    
                    // If we got this far we failed
                    
                    // Call our completion handler
                    [self callCompletionHandler:NO data:nil error:error close:YES];
                }
                
                break;
            }
            case kCloudDocumentStrategyPickVersion: {
                // Check if file already exists
                if ([results count] != 0) { // File already exists in iCloud
                    NSMetadataItem *documentItem = [[metadataQuery results] lastObject];
                    
                    if ([[documentItem valueForAttribute:NSMetadataUbiquitousItemIsDownloadedKey] boolValue])
                    {
                        // Stop querying
                        [metadataQuery disableUpdates];
                        [metadataQuery stopQuery];
                        
                        // Check if version hash matches
                        NSArray *conflictVersions = [NSFileVersion unresolvedConflictVersionsOfItemAtURL:documentCloudURL];
                        NSFileVersion *currentVersion = [NSFileVersion currentVersionOfItemAtURL:documentCloudURL];
                        
                        int error;
                        if (currentVersion != nil) {
                            NSMutableArray *allVersions = [NSMutableArray arrayWithObject:currentVersion];
                            if (conflictVersions != nil)
                                [allVersions addObjectsFromArray:conflictVersions];
                            
                            NSMutableData *hash = [NSMutableData data];
                            for (NSFileVersion *version in allVersions) {
                                NSData *persistentIdentifier = [NSKeyedArchiver archivedDataWithRootObject:version.persistentIdentifier];
                                
                                [hash appendData:persistentIdentifier];
                                [hash appendData:[NSKeyedArchiver archivedDataWithRootObject:version.modificationDate]];
                            }
                            
                            unsigned char result[16];
                            CC_MD5(hash.bytes, (unsigned int)hash.length, result);
                            NSString *md5Hash = [NSString stringWithFormat:
                                                 @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
                                                 result[0], result[1], result[2], result[3],
                                                 result[4], result[5], result[6], result[7],
                                                 result[8], result[9], result[10], result[11],
                                                 result[12], result[13], result[14], result[15]
                                                 ];
                            if ([documentVersionsHash isEqualToString:md5Hash]) {
                                // Check if this item version matches
                                NSFileVersion *pickedVersion = [NSFileVersion versionOfItemAtURL:documentCloudURL forPersistentIdentifier:[NSKeyedUnarchiver unarchiveObjectWithData:documentVersionIdentifier]];
                                
                                if (pickedVersion != nil) {
                                    // Attempt to acquire cloud document
                                    document = [[JCPDocument alloc] initWithFileURL:documentCloudURL];
                                    if (document != nil) {
                                        NSError *replaceError = nil;
                                        
                                        // If we picked a non-current version, replace
                                        if (pickedVersion.isConflict) {
                                            [pickedVersion replaceItemAtURL:documentCloudURL options:0 error:&replaceError];
                                        }
                                        
                                        if (replaceError == nil && [document removeOtherVersions]) {
                                            // Mark as resolved
                                            for (NSFileVersion* version in allVersions) {
                                                if ([version isEqual:pickedVersion])
                                                    continue;
                                                
                                                version.resolved = YES;
                                            }
                                            
                                            [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:YES];
                                            break;
                                        } else {
                                            error = kCloudDocumentErrorNativeError;
                                        }
                                    } else {
                                        error = kCloudDocumentErrorInvalidArguments;
                                    }
                                } else {
                                    error = kCloudDocumentErrorInvalidVersionIdentifier;
                                }
                            } else {
                                error = kCloudDocumentErrorInvalidVersionsHash;
                            }
                        } else {
                            error = kCloudDocumentErrorPluginError;
                        }
                        
                        // If we got this far we failed
                        
                        // Call our completion handler
                        [self callCompletionHandler:NO data:nil error:error close:YES];
                    } else {
                        if (![[documentItem valueForAttribute:NSMetadataUbiquitousItemIsDownloadingKey] boolValue])
                            [[[[NSFileManager alloc] init] autorelease] startDownloadingUbiquitousItemAtURL:documentCloudURL error:nil];
                        
                        // Start a timer to prevent stalled downloads
                        documentLastProgress = 0.0f;
                        [self startDownloadTimeoutTimer];
                    }
                } else {
                    // Stop querying
                    [metadataQuery disableUpdates];
                    [metadataQuery stopQuery];
                    
                    // Document may not exist at all or is not in iCloud so it won't have versions
                    [documentVersionIdentifier release];
                    documentVersionIdentifier = nil;
                    [documentVersionsHash release];
                    documentVersionsHash = nil;
                    
                    // Close any open document
                    [self closeDocumentWithNotification:NO];
                    
                    // Attempt to acquire local document
                    document = [[JCPDocument alloc] initWithFileURL:documentLocalURL];
                    
                    int error;
                    if (document != nil) {
                        // Check if file already exists
                        BOOL exists = [document existsWithError:&error];
                        
                        if (error == kCloudDocumentErrorNone) {
                            if (exists) {
                                // Attempt to render document ubiquitous
                                if ([document moveDocumentToURL:documentCloudURL overwrite:YES error:nil]) {
                                    // Document is now ubiquitous but this call to pick version was wrong all the way, just indicate invalid hash
                                    error = kCloudDocumentErrorInvalidVersionsHash;
                                } else {
                                    error = kCloudDocumentErrorNativeError;
                                }
                            } else {
                                // File does not exist at all
                                error = kCloudDocumentErrorDocumentNotFound;
                            }
                        }
                    } else {
                        error = kCloudDocumentErrorInvalidArguments;
                    }
                    
                    // If we got this far we failed
                    
                    // Call our completion handler
                    [self callCompletionHandler:NO data:nil error:error close:YES];
                }
                
                break;
            }
            default:
                // Stop querying
                [metadataQuery disableUpdates];
                [metadataQuery stopQuery];
                [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorPluginError close:YES];
                break;
        }
        
        // Madness...
        if (metadataQuery.isStopped) {
            [metadataQuery release];
            metadataQuery = [[NSMetadataQuery alloc] init];
            [metadataQuery setSearchScopes:[NSArray arrayWithObject:NSMetadataQueryUbiquitousDocumentsScope]];
        }
    });
}

- (void)metadataQueryDidUpdateNotification:(NSNotification *)notification {
    // Process results on another thread
    dispatch_async(managerQueue, ^{
        NSMetadataQuery *query = [notification object];
        if (query != metadataQuery)
            return;
        
        // We may have already stopped this
        if (metadataQuery.isStopped)
            return;
        
        NSArray *results = [metadataQuery results];
        
        switch (documentStrategy) {
            case kCloudDocumentStrategyCreateOrOpen:
            case kCloudDocumentStrategyOpen: {
                // Check download status
                float progress = -1.0f;
                NSMetadataItem *item = [results lastObject];
                if (![[item valueForAttribute:NSMetadataUbiquitousItemIsDownloadedKey] boolValue])
                {
                    if (![[item valueForAttribute:NSMetadataUbiquitousItemIsDownloadingKey] boolValue]) {
                        [[[[NSFileManager alloc] init] autorelease] startDownloadingUbiquitousItemAtURL:[item valueForAttribute:NSMetadataItemURLKey] error:nil];
                        
                        if (progress != -1.0f)
                            progress *= 0.5f;
                        else
                            progress = 0.0f;
                    } else {
                        if (progress != -1.0f)
                            progress = (progress + (float)[[item valueForAttribute:NSMetadataUbiquitousItemPercentDownloadedKey] doubleValue]) * 0.5f;
                        else
                            progress = (float)[[item valueForAttribute:NSMetadataUbiquitousItemPercentDownloadedKey] doubleValue];
                    }
                    
                    // Update last progress time if we made progress
                    if (documentLastProgress != progress) {
                        documentLastProgress = progress;
                        [documentTimeoutDownloadTime release];
                        documentTimeoutDownloadTime = [[NSDate date] retain];
                    }
                    
                    // Notify delegate of progress change
                    if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeProgress:progress:)])
                        [self.documentDelegate cloudDocumentManagerDidChangeProgress:self progress:progress];
                } else {
                    // Done downloading
                    progress = 100.0f;
                    [self stopDownloadTimeoutTimer];
                    
                    // Notify delegate of progress change
                    if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeProgress:progress:)])
                        [self.documentDelegate cloudDocumentManagerDidChangeProgress:self progress:progress];
                    
                    // Stop querying
                    [metadataQuery disableUpdates];
                    [metadataQuery stopQuery];
                    
                    // Register for document state changed notifications
                    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(documentStateChangedNotification:) name:JCPDocumentStateChangedNotification object:document];
                    
                    // File already exists, open it
                    if (![document openDocument]) { // Close document on failure
                        [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorNativeError close:YES];
                    } else {
                        [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:NO];
                    }
                }
                
                break;
            }
            case kCloudDocumentStrategyCopy:
            case kCloudDocumentStrategyMove: {
                // Check for stall downloads -- fail after 10 secs of nothing happening
                
                // Check download status
                float progress = -1.0f;
                BOOL blockHasUndownloadedFiles = NO;
                for (NSMetadataItem *item in results) {
                    if (![[item valueForAttribute:NSMetadataUbiquitousItemIsDownloadedKey] boolValue])
                    {
                        blockHasUndownloadedFiles = YES;
                        if (![[item valueForAttribute:NSMetadataUbiquitousItemIsDownloadingKey] boolValue]) {
                            [[[[NSFileManager alloc] init] autorelease] startDownloadingUbiquitousItemAtURL:[item valueForAttribute:NSMetadataItemURLKey] error:nil];
                            
                            if (progress != -1.0f)
                                progress *= 0.5f;
                            else
                                progress = 0.0f;
                        } else {
                            if (progress != -1.0f)
                                progress = (progress + (float)[[item valueForAttribute:NSMetadataUbiquitousItemPercentDownloadedKey] doubleValue]) * 0.5f;
                            else
                                progress = (float)[[item valueForAttribute:NSMetadataUbiquitousItemPercentDownloadedKey] doubleValue];
                        }
                    }
                }
                
                // Done downloading? step 1
                if (!blockHasUndownloadedFiles) {
                    progress = 100.0f;
                    [self stopDownloadTimeoutTimer];
                } else {
                    // Update last progress time if we made progress
                    if (documentLastProgress != progress) {
                        documentLastProgress = progress;
                        [documentTimeoutDownloadTime release];
                        documentTimeoutDownloadTime = [[NSDate date] retain];
                    }
                    
                }
                
                // Notify delegate of progress change
                if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeProgress:progress:)])
                    [self.documentDelegate cloudDocumentManagerDidChangeProgress:self progress:progress];
                
                // Done downloading? step 2
                if (!blockHasUndownloadedFiles) {
                    // Call our completion handler with our result!
                    BOOL success;
                    int error;
                    if (documentStrategy == kCloudDocumentStrategyCopy)
                        success = [document copyDocumentToURL:documentCopyMoveURL overwrite:documentCopyMoveOverwrite error:&error];
                    else
                        success = [document moveDocumentToURL:documentCopyMoveURL overwrite:documentCopyMoveOverwrite error:&error];
                    
                    [self callCompletionHandler:success data:nil error:error close:YES];
                    
                    // Stop query
                    [metadataQuery disableUpdates];
                    [metadataQuery stopQuery];
                }
                
                break;
            }
            case kCloudDocumentStrategyHasConflictVersions: {
                // Check download status
                float progress = -1.0f;
                NSMetadataItem *item = [results lastObject];
                if (![[item valueForAttribute:NSMetadataUbiquitousItemIsDownloadedKey] boolValue])
                {
                    if (![[item valueForAttribute:NSMetadataUbiquitousItemIsDownloadingKey] boolValue]) {
                        [[[[NSFileManager alloc] init] autorelease] startDownloadingUbiquitousItemAtURL:[item valueForAttribute:NSMetadataItemURLKey] error:nil];
                        
                        if (progress != -1.0f)
                            progress *= 0.5f;
                        else
                            progress = 0.0f;
                    } else {
                        if (progress != -1.0f)
                            progress = (progress + (float)[[item valueForAttribute:NSMetadataUbiquitousItemPercentDownloadedKey] doubleValue]) * 0.5f;
                        else
                            progress = (float)[[item valueForAttribute:NSMetadataUbiquitousItemPercentDownloadedKey] doubleValue];
                    }
                    
                    // Update last progress time if we made progress
                    if (documentLastProgress != progress) {
                        documentLastProgress = progress;
                        [documentTimeoutDownloadTime release];
                        documentTimeoutDownloadTime = [[NSDate date] retain];
                    }
                    
                    // Notify delegate of progress change
                    if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeProgress:progress:)])
                        [self.documentDelegate cloudDocumentManagerDidChangeProgress:self progress:progress];
                } else {
                    // Done downloading
                    progress = 100.0f;
                    [self stopDownloadTimeoutTimer];
                    
                    // Notify delegate of progress change
                    if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeProgress:progress:)])
                        [self.documentDelegate cloudDocumentManagerDidChangeProgress:self progress:progress];
                    
                    // Stop querying
                    [metadataQuery disableUpdates];
                    [metadataQuery stopQuery];
                    
                    // Fetch versions
                    NSArray *versions = [NSFileVersion unresolvedConflictVersionsOfItemAtURL:documentCloudURL];
                    if (versions != nil && versions.count > 0) { // Conflicts
                        // Call our completion handler
                        [self callCompletionHandler:YES data:[NSNumber numberWithBool:YES] error:kCloudDocumentErrorNone close:YES];
                        
                        break;
                    } else if ([NSFileVersion currentVersionOfItemAtURL:documentCloudURL] != nil) { // Do we even have a current version? If yes that means no conflict
                        // Call our completion handler
                        [self callCompletionHandler:YES data:[NSNumber numberWithBool:NO] error:kCloudDocumentErrorNone close:YES];
                        
                        break;
                    }
                    
                    // We should never get there
                    // Call our completion handler
                    [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorPluginError close:YES];
                }
                
                break;
            }
            case kCloudDocumentStrategyGetAllVersions: {
                // Check download status
                float progress = -1.0f;
                NSMetadataItem *item = [results lastObject];
                if (![[item valueForAttribute:NSMetadataUbiquitousItemIsDownloadedKey] boolValue])
                {
                    if (![[item valueForAttribute:NSMetadataUbiquitousItemIsDownloadingKey] boolValue]) {
                        [[[[NSFileManager alloc] init] autorelease] startDownloadingUbiquitousItemAtURL:[item valueForAttribute:NSMetadataItemURLKey] error:nil];
                        
                        if (progress != -1.0f)
                            progress *= 0.5f;
                        else
                            progress = 0.0f;
                    } else {
                        if (progress != -1.0f)
                            progress = (progress + (float)[[item valueForAttribute:NSMetadataUbiquitousItemPercentDownloadedKey] doubleValue]) * 0.5f;
                        else
                            progress = (float)[[item valueForAttribute:NSMetadataUbiquitousItemPercentDownloadedKey] doubleValue];
                    }
                    
                    // Update last progress time if we made progress
                    if (documentLastProgress != progress) {
                        documentLastProgress = progress;
                        [documentTimeoutDownloadTime release];
                        documentTimeoutDownloadTime = [[NSDate date] retain];
                    }
                    
                    // Notify delegate of progress change
                    if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeProgress:progress:)])
                        [self.documentDelegate cloudDocumentManagerDidChangeProgress:self progress:progress];
                } else {
                    // Done downloading
                    progress = 100.0f;
                    [self stopDownloadTimeoutTimer];
                    
                    // Notify delegate of progress change
                    if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeProgress:progress:)])
                        [self.documentDelegate cloudDocumentManagerDidChangeProgress:self progress:progress];
                    
                    // Stop querying
                    [metadataQuery disableUpdates];
                    [metadataQuery stopQuery];
                    
                    // Fetch versions
                    NSArray *conflictVersions = [NSFileVersion unresolvedConflictVersionsOfItemAtURL:documentCloudURL];
                    NSFileVersion *currentVersion = [NSFileVersion currentVersionOfItemAtURL:documentCloudURL];
                    
                    if (currentVersion != nil) {
                        NSMutableArray *allVersions = [NSMutableArray arrayWithObject:currentVersion];
                        if (conflictVersions != nil)
                            [allVersions addObjectsFromArray:conflictVersions];
                        
                        // Call our completion handler
                        [self callCompletionHandler:YES data:allVersions error:kCloudDocumentErrorNone close:YES];
                        
                        break;
                    }
                    
                    // We should never get there
                    // Call our completion handler
                    [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorPluginError close:YES];
                }
                
                break;
            }
            case kCloudDocumentStrategyOpenVersion: {
                // Check download status
                float progress = -1.0f;
                NSMetadataItem *item = [results lastObject];
                if (![[item valueForAttribute:NSMetadataUbiquitousItemIsDownloadedKey] boolValue])
                {
                    if (![[item valueForAttribute:NSMetadataUbiquitousItemIsDownloadingKey] boolValue]) {
                        [[[[NSFileManager alloc] init] autorelease] startDownloadingUbiquitousItemAtURL:[item valueForAttribute:NSMetadataItemURLKey] error:nil];
                        
                        if (progress != -1.0f)
                            progress *= 0.5f;
                        else
                            progress = 0.0f;
                    } else {
                        if (progress != -1.0f)
                            progress = (progress + (float)[[item valueForAttribute:NSMetadataUbiquitousItemPercentDownloadedKey] doubleValue]) * 0.5f;
                        else
                            progress = (float)[[item valueForAttribute:NSMetadataUbiquitousItemPercentDownloadedKey] doubleValue];
                    }
                    
                    // Update last progress time if we made progress
                    if (documentLastProgress != progress) {
                        documentLastProgress = progress;
                        [documentTimeoutDownloadTime release];
                        documentTimeoutDownloadTime = [[NSDate date] retain];
                    }
                    
                    // Notify delegate of progress change
                    if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeProgress:progress:)])
                        [self.documentDelegate cloudDocumentManagerDidChangeProgress:self progress:progress];
                } else {
                    // Done downloading
                    progress = 100.0f;
                    [self stopDownloadTimeoutTimer];
                    
                    // Notify delegate of progress change
                    if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeProgress:progress:)])
                        [self.documentDelegate cloudDocumentManagerDidChangeProgress:self progress:progress];
                    
                    // Stop querying
                    [metadataQuery disableUpdates];
                    [metadataQuery stopQuery];
                    
                    // Check if this item version matches
                    NSFileVersion *version = [NSFileVersion versionOfItemAtURL:documentCloudURL forPersistentIdentifier:[NSKeyedUnarchiver unarchiveObjectWithData:documentVersionIdentifier]];
                    [documentVersionIdentifier release];
                    documentVersionIdentifier = nil;
                    
                    int error;
                    if (version != nil) {
                        // Mark document as non ubiquitous
                        documentIsUbiquitous = NO;
                        
                        // Close any open document
                        [self closeDocumentWithNotification:NO];
                        
                        // Attempt to acquire version document
                        document = [[JCPDocument alloc] initWithFileURL:version.URL];
                        if (document != nil) {
                            // Register for document state changed notifications
                            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(documentStateChangedNotification:) name:JCPDocumentStateChangedNotification object:document];
                            
                            // Check if file already exists
                            BOOL exists = [document existsWithError:&error];
                            
                            if (error == kCloudDocumentErrorNone) {
                                if (exists) {
                                    // File already exists, open it
                                    if ([document openDocument]) {
                                        [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:NO];
                                        break;
                                    } else {
                                        error = kCloudDocumentErrorNativeError;
                                    }
                                } else {
                                    error = kCloudDocumentErrorDocumentNotFound;
                                }
                            }
                        } else {
                            error = kCloudDocumentErrorPluginError;
                        }
                    } else {
                        error = kCloudDocumentErrorInvalidVersionIdentifier;
                    }
                    
                    // If we got this far we failed
                    
                    // Call our completion handler
                    [self callCompletionHandler:NO data:nil error:error close:YES];
                }
                
                break;
            }
            case kCloudDocumentStrategyPickVersion: {
                // Check download status
                float progress = -1.0f;
                NSMetadataItem *item = [results lastObject];
                if (![[item valueForAttribute:NSMetadataUbiquitousItemIsDownloadedKey] boolValue])
                {
                    if (![[item valueForAttribute:NSMetadataUbiquitousItemIsDownloadingKey] boolValue]) {
                        [[[[NSFileManager alloc] init] autorelease] startDownloadingUbiquitousItemAtURL:[item valueForAttribute:NSMetadataItemURLKey] error:nil];
                        
                        if (progress != -1.0f)
                            progress *= 0.5f;
                        else
                            progress = 0.0f;
                    } else {
                        if (progress != -1.0f)
                            progress = (progress + (float)[[item valueForAttribute:NSMetadataUbiquitousItemPercentDownloadedKey] doubleValue]) * 0.5f;
                        else
                            progress = (float)[[item valueForAttribute:NSMetadataUbiquitousItemPercentDownloadedKey] doubleValue];
                    }
                    
                    // Update last progress time if we made progress
                    if (documentLastProgress != progress) {
                        documentLastProgress = progress;
                        [documentTimeoutDownloadTime release];
                        documentTimeoutDownloadTime = [[NSDate date] retain];
                    }
                    
                    // Notify delegate of progress change
                    if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeProgress:progress:)])
                        [self.documentDelegate cloudDocumentManagerDidChangeProgress:self progress:progress];
                } else {
                    // Done downloading
                    progress = 100.0f;
                    [self stopDownloadTimeoutTimer];
                    
                    // Notify delegate of progress change
                    if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeProgress:progress:)])
                        [self.documentDelegate cloudDocumentManagerDidChangeProgress:self progress:progress];
                    
                    // Stop querying
                    [metadataQuery disableUpdates];
                    [metadataQuery stopQuery];
                    
                    // Check if version hash matches
                    NSArray *conflictVersions = [NSFileVersion unresolvedConflictVersionsOfItemAtURL:documentCloudURL];
                    NSFileVersion *currentVersion = [NSFileVersion currentVersionOfItemAtURL:documentCloudURL];
                    
                    int error;
                    if (currentVersion != nil) {
                        NSMutableArray *allVersions = [NSMutableArray arrayWithObject:currentVersion];
                        if (conflictVersions != nil)
                            [allVersions addObjectsFromArray:conflictVersions];
                        
                        NSMutableData *hash = [NSMutableData data];
                        for (NSFileVersion *version in allVersions) {
                            NSData *persistentIdentifier = [NSKeyedArchiver archivedDataWithRootObject:version.persistentIdentifier];
                            
                            [hash appendData:persistentIdentifier];
                            [hash appendData:[NSKeyedArchiver archivedDataWithRootObject:version.modificationDate]];
                        }
                        
                        unsigned char result[16];
                        CC_MD5(hash.bytes, (unsigned int)hash.length, result);
                        NSString *md5Hash = [NSString stringWithFormat:
                                             @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
                                             result[0], result[1], result[2], result[3],
                                             result[4], result[5], result[6], result[7],
                                             result[8], result[9], result[10], result[11],
                                             result[12], result[13], result[14], result[15]
                                             ];
                        if ([documentVersionsHash isEqualToString:md5Hash]) {
                            // Check if this item version matches
                            NSFileVersion *pickedVersion = [NSFileVersion versionOfItemAtURL:documentCloudURL forPersistentIdentifier:[NSKeyedUnarchiver unarchiveObjectWithData:documentVersionIdentifier]];
                            
                            if (pickedVersion != nil) {
                                // Attempt to acquire cloud document
                                document = [[JCPDocument alloc] initWithFileURL:documentCloudURL];
                                if (document != nil) {
                                    NSError *replaceError = nil;
                                    
                                    // If we picked a non-current version, replace
                                    if (pickedVersion.isConflict) {
                                        [pickedVersion replaceItemAtURL:documentCloudURL options:0 error:&replaceError];
                                    }
                                    
                                    if (replaceError == nil && [document removeOtherVersions]) {
                                        // Mark as resolved
                                        for (NSFileVersion* version in allVersions) {
                                            if ([version isEqual:pickedVersion])
                                                continue;
                                            
                                            version.resolved = YES;
                                        }
                                        
                                        [self callCompletionHandler:YES data:nil error:kCloudDocumentErrorNone close:YES];
                                        break;
                                    } else {
                                        error = kCloudDocumentErrorNativeError;
                                    }
                                } else {
                                    error = kCloudDocumentErrorInvalidArguments;
                                }
                            } else {
                                error = kCloudDocumentErrorInvalidVersionIdentifier;
                            }
                        } else {
                            error = kCloudDocumentErrorInvalidVersionsHash;
                        }
                    } else {
                        error = kCloudDocumentErrorPluginError;
                    }
                    
                    // If we got this far we failed
                    
                    // Call our completion handler
                    [self callCompletionHandler:NO data:nil error:error close:YES];
                }
                
                break;
            }
            default:
                // Stop query
                [metadataQuery disableUpdates];
                [metadataQuery stopQuery];
                [self callCompletionHandler:NO data:nil error:kCloudDocumentErrorPluginError close:YES];
                break;
        }
        
        // Madness...
        if (metadataQuery.isStopped) {
            [metadataQuery release];
            metadataQuery = [[NSMetadataQuery alloc] init];
            [metadataQuery setSearchScopes:[NSArray arrayWithObject:NSMetadataQueryUbiquitousDocumentsScope]];
        }
    });
}

///////////////////////////////////////
// JCPDocument Notifications Handling //
///////////////////////////////////////

#pragma mark JCPDocument Notifications Handling

- (void)documentStateChangedNotification:(NSNotification *)notification {
    // Failsafe
    if (document == nil)
        return;
    
    // Get state as reported by JCPDocument
    JCPDocumentState newState = [document documentState];
    
    // Make it a state we will pass to our managed code
    if (newState == JCPDocumentStateNormal) {
        // Document is in normal state and can be processed
        documentState = kCloudDocumentStateNormal;
    } else if ((newState & JCPDocumentStateClosed) || (newState & JCPDocumentStateSavingError)) {
        // We consider those states as fail for now -- Close document
        [self closeDocumentWithNotification:NO];
    } else if (newState & JCPDocumentStateInConflict) {
        // We don't really care about this one so let's just mark it as normal
        documentState = kCloudDocumentStateNormal;
    } else if (newState & JCPDocumentStateEditingDisabled) {
        // We don't really care about this one so let's just mark it as normal
        documentState = kCloudDocumentStateNormal;
    }
    
    // Notify delegate of state change
    if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(cloudDocumentManagerDidChangeState:state:)])
        [self.documentDelegate cloudDocumentManagerDidChangeState:self state:documentState];
}


@end


