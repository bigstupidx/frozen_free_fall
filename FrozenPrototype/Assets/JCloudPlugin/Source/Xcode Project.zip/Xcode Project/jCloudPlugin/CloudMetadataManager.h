//
//  CloudMetadataManager.h
//  jCloudPlugin
//
//  Created by Jérémie Di Prizio on 03/10/13.
//  Copyright (c) 2011-2013 jemast software.
//

#import <Foundation/Foundation.h>

@interface CloudMetadataManager : NSObject {
    dispatch_queue_t        managerQueue;
    
    NSMetadataQuery         *metadataQuery;
    NSMutableDictionary     *metadataDictionary;
    
    BOOL                    shouldMessage;
    NSInteger               messageCallbackPointer;
}

@property (readwrite) BOOL shouldMessage;
@property (readwrite) NSInteger messageCallbackPointer;

+ (CloudMetadataManager *)sharedInstance;

- (void)resetUbiquityStatus;


@end
