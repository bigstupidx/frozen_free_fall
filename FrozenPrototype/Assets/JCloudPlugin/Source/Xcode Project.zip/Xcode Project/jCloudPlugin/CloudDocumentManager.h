//
//  CloudDocumentManager.h
//  CloudDocumentManager
//
//  Created by Jérémie Di Prizio on 04/11/11.
//  Copyright (c) 2011-2013 jemast software.
//

#import <Foundation/Foundation.h>

enum {
    kCloudDocumentStateClosed = 0,
    kCloudDocumentStateProcessing,
    kCloudDocumentStateNormal,
    kCloudDocumentStateInConflict,
    kCloudDocumentStateEditingDisabled
};

enum {
    kCloudDocumentStrategyCreateOrOpen = 0,
    kCloudDocumentStrategyCreate,
    kCloudDocumentStrategyOpen,
    kCloudDocumentStrategyDelete,
    kCloudDocumentStrategyCheckExistence,
    kCloudDocumentStrategyGetModificationDate,
    kCloudDocumentStrategyCopy,
    kCloudDocumentStrategyMove,
    kCloudDocumentStrategyHasConflictVersions,
    kCloudDocumentStrategyGetAllVersions,
    kCloudDocumentStrategyOpenVersion,
    kCloudDocumentStrategyPickVersion
};

enum {
    kCloudDocumentErrorNone = -1,
    kCloudDocumentErrorPluginError,
    kCloudDocumentErrorInvalidArguments,
    kCloudDocumentErrorDocumentNotFound,
    kCloudDocumentErrorOverwriteError,
    kCloudDocumentErrorNativeError,
    kCloudDocumentErrorCloudUnavailable,
    kCloudDocumentErrorInvalidVersionIdentifier,
    kCloudDocumentErrorInvalidVersionsHash,
    kCloudDocumentErrorDownloadTimeout,
    kCloudDocumentErrorInvalidPlatform
};


@class JCPDocument;
@protocol CloudDocumentManagerDelegate;


@interface CloudDocumentManager : NSObject {
    NSMetadataQuery                     *metadataQuery;
    void                                (^completionHandlerBlock)(BOOL,id,int);
    
    JCPDocument                          *document;
    NSString                            *documentPath;
    BOOL                                documentIsDirectory;
    NSInteger                           documentState;
    BOOL                                documentIsUbiquitous;
    
    NSURL                               *documentCloudURL;
    NSURL                               *documentLocalURL;
    
    NSURL                               *documentCopyMoveURL;
    BOOL                                documentCopyMoveOverwrite;
    
    NSInteger                           documentStrategy;
    
    NSNumber                            *documentUniqueIdentifier;
    
    float                               documentLastProgress;
    
    dispatch_source_t                   documentTimeoutTimer;
    NSDate                              *documentTimeoutQueryTime;
    NSDate                              *documentTimeoutDownloadTime;
    
    NSData                              *documentVersionIdentifier;
    NSString                            *documentVersionsHash;
    
    id<CloudDocumentManagerDelegate>    documentDelegate;
    
    dispatch_queue_t                    managerQueue;
    
    NSInteger                           accessCount;
}

@property (nonatomic, readonly) NSString *documentPath;
@property (nonatomic, readonly) NSInteger documentState;
//@property (nonatomic, readonly) NSDate *documentModificationDate;
@property (nonatomic, readonly) NSNumber *documentUniqueIdentifier;
@property (nonatomic, assign) id<CloudDocumentManagerDelegate> documentDelegate;
//@property (retain) NSOperationQueue *managerQueue;
@property (readwrite) NSInteger accessCount;


+ (void)setPersistentDataPath:(NSString *)path;
+ (NSURL *)urlForUbiquityContainerIdentifier;
+ (NSURL *)documentsDirectoryURL;
+ (void)resetUbiquityStatus;

- (CloudDocumentManager *)initWithPrepareDataDocumentAtPath:(NSString *)path isDirectory:(BOOL)directory uniqueIdentifier:(NSNumber *)uniqueIdentifier delegate:(id)delegate;
+ (CloudDocumentManager *)prepareDataDocumentAtPath:(NSString *)path isDirectory:(BOOL)directory uniqueIdentifier:(NSNumber *)uniqueIdentifier delegate:(id)delegate;

- (void)createOrOpenDocumentWithCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler;
- (void)createDocumentWithCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler;
- (void)openDocumentWithCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler;
- (void)deleteDocumentWithCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler;
- (BOOL)writeContents:(id)contents;
- (NSData *)readContents;
- (void)saveDocumentImmediately;
- (void)checkExistenceWithCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler;
- (void)getModificationDateWithCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler;
- (void)copyToPath:(NSString *)destinationPath overwrite:(BOOL)overwrite withCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler;
- (void)moveToPath:(NSString *)destinationPath overwrite:(BOOL)overwrite withCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler;
- (void)getHasConflictVersionsWithCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler;
- (void)getAllVersionsWithCompletionHandler:(void (^)(BOOL success, id data, int error))completionHandler;
- (void)openDocumentWithVersionIdentifier:(NSData *)versionIdentifier completionHandler:(void (^)(BOOL success, id data, int error))completionHandler;
- (void)pickDocumentWithVersionIdentifier:(NSData *)versionIdentifier versionsHash:(NSString *)md5Hash completionHandler:(void (^)(BOOL success, id data, int error))completionHandler;


@end




@protocol CloudDocumentManagerDelegate <NSObject>

- (void)cloudDocumentManagerDidChangeState:(CloudDocumentManager *)manager state:(NSInteger)state;
- (void)cloudDocumentManagerDidChangeProgress:(CloudDocumentManager *)manager progress:(float)progress;


@end

