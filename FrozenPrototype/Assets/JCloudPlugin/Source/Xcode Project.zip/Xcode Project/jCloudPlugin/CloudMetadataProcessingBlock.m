//
//  CloudMetadataProcessingBlock.m
//  jCloudPlugin
//
//  Created by Jérémie Di Prizio on 04/10/13.
//  Copyright (c) 2011-2013 jemast software.
//

#import "CloudMetadataProcessingBlock.h"

@implementation CloudMetadataProcessingBlock

@synthesize block;

- (void)dealloc {
    [block release];
    [super dealloc];
}


@end
