//
//  CloudMetadataProcessingBlock.h
//  jCloudPlugin
//
//  Created by Jérémie Di Prizio on 04/10/13.
//  Copyright (c) 2011-2013 jemast software.
//

#import <Foundation/Foundation.h>

@interface CloudMetadataProcessingBlock : NSObject {
    dispatch_block_t block;
}

@property (copy, nonatomic) dispatch_block_t block;

@end
