//
//  CloudDataManager.h
//  iCloudPlugin
//
//  Created by Jérémie Di Prizio on 08/11/11.
//  Copyright (c) 2011-2013 jemast software.
//

#import <Foundation/Foundation.h>

@interface CloudDataManager : NSObject {
    NSMutableDictionary *cloudDataFallbackDictionary;
    
    NSURL *localUbiquityDictionaryRepresentationURL;
    
    BOOL shouldMessage;
    BOOL isSaving;
    NSInteger messageCallbackPointer;
}

@property (readwrite) BOOL shouldMessage;
@property (readwrite) BOOL isSaving;
@property (readwrite) NSInteger messageCallbackPointer;


+ (CloudDataManager *)sharedInstance;

+ (void)setPersistentDataPath:(NSString *)path;

- (void)resetUbiquityStatus;
- (BOOL)isCloudAvailable;

- (void)setInt:(NSInteger)value forKey:(NSString *)key;
- (BOOL)getIntForKey:(NSString *)key value:(NSInteger *)value;
- (void)setFloat:(float)value forKey:(NSString *)key;
- (BOOL)getFloatForKey:(NSString *)key value:(float *)value;
- (void)setString:(NSString *)value forKey:(NSString *)key;
- (BOOL)getStringForKey:(NSString *)key value:(NSString **)value;
- (BOOL)hasKey:(NSString *)key;
- (void)deleteKey:(NSString *)key;
- (void)deleteAll;
- (void)save;


@end
