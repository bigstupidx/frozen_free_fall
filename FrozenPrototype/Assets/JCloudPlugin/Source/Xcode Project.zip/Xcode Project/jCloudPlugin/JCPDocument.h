//
//  JCPDocument.h
//  jCloudPlugin
//
//  Created by Jérémie Di Prizio on 28/11/11.
//  Copyright (c) 2011-2013 jemast software.
//

#import <Foundation/Foundation.h>

enum {
    JCPDocumentStateNormal          = 0,
    JCPDocumentStateClosed          = 1 << 0, // The document has either not been successfully opened, or has been since closed. Document properties may not be valid.
    JCPDocumentStateInConflict      = 1 << 1, // Conflicts exist for the document's fileURL. They can be accessed through +[NSFileVersion otherVersionsOfItemAtURL:].
    JCPDocumentStateSavingError     = 1 << 2, // An error has occurred that prevents the document from saving.
    JCPDocumentStateEditingDisabled = 1 << 3  // Set before calling -disableEditing. The document is is busy and it is not currently safe to allow user edits. -enableEditing will be called when it becomes safe to edit again.
};
typedef NSInteger JCPDocumentState;

static NSString *const JCPDocumentStateChangedNotification = @"JCPDocumentStateChangedNotification";

@interface JCPDocument : NSObject <NSFilePresenter> {
    NSURL               *fileURL;
    NSDate              *fileModificationDate;
    JCPDocumentState     documentState;
    
    BOOL                fileIsWritable;
    
    NSUInteger          changeCountToken;
    NSObject            *changeCountTokenMutex;
    
    id                  fileData;
    
    BOOL                fileIsDirectory;
}

@property(readonly, retain) NSURL *fileURL;
@property(readonly, retain) NSDate *fileModificationDate;
@property (readonly) JCPDocumentState documentState;
@property (readonly) BOOL fileIsWritable;
@property (readonly) BOOL fileIsDirectory;
@property (readonly) BOOL hasUnsavedChanges;
@property (readonly, retain) id fileData;

- (id)initWithFileURL:(NSURL *)url;
+ (id)documentWithFileURL:(NSURL *)url;
- (id)initWithDirectoryURL:(NSURL *)url;
+ (id)documentWithDirectoryURL:(NSURL *)url;

- (BOOL)existsWithError:(int *)error;
- (NSDate *)modificationDate;

- (BOOL)openDocument;
- (BOOL)closeDocument;
- (BOOL)saveDocument;
- (BOOL)deleteDocument;
- (BOOL)copyDocumentToURL:(NSURL *)destinationURL overwrite:(BOOL)overwrite error:(int *)error;
- (BOOL)moveDocumentToURL:(NSURL *)destinationURL overwrite:(BOOL)overwrite error:(int *)error;
- (BOOL)removeOtherVersions;

- (BOOL)setContents:(NSData *)data;
- (void)shouldAutosaveImmediately;


@end
