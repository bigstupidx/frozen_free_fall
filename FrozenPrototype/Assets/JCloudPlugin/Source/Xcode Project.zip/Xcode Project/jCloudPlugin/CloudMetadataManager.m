//
//  CloudMetadataManager.m
//  jCloudPlugin
//
//  Created by Jérémie Di Prizio on 03/10/13.
//  Copyright (c) 2011-2013 jemast software.
//

#import "CloudMetadataManager.h"
#import "CloudMetadataProcessingBlock.h"



// EXTERN DECLATIONS FOR UNMANAGED TO MANAGED CALLBACK METHODS
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
EXTERN_API_C(void) UnitySendMessage(const char *object, const char *method, const char *message) __attribute__((weak));
#elif TARGET_OS_MAC
typedef void ManagedCallbackPointer(const char *message);
#endif


@implementation CloudMetadataManager

@synthesize messageCallbackPointer;


// Quick and dirty singleton implementation
+ (CloudMetadataManager *)sharedInstance {
    static dispatch_once_t pred = 0;
    static id _sharedObject = nil;
    dispatch_once(&pred, ^{
        _sharedObject = [[self alloc] init];
    });
    return _sharedObject;
}

//////////////////////////////////////
// Initialization & Dealloc Methods //
//////////////////////////////////////

#pragma mark Initialization & Dealloc Methods

- (id)init {
    if ((self = [super init])) {
        managerQueue = dispatch_queue_create("com.jemast.JCloudPlugin-MetadataManager", DISPATCH_QUEUE_SERIAL);
        
        metadataDictionary = [[NSMutableDictionary alloc] init];
    }
    
    return self;
}

- (void)dealloc {
    dispatch_release(managerQueue);
    
    [metadataQuery disableUpdates];
    [metadataQuery stopQuery];
    [metadataQuery release];
    
    [metadataDictionary release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    [super dealloc];
}

static BOOL didCheckUbiquityStatus = false;

+ (NSURL *)urlForUbiquityContainerIdentifier {
    // This is our iCloud path our nil if no-iCloud
    static NSURL *urlForUbiquityContainerIdentifier = nil;
    
    if (!didCheckUbiquityStatus) {
        // Check iCloud methods are available
        if (![[NSFileManager defaultManager] respondsToSelector:@selector(URLForUbiquityContainerIdentifier:)])
            return nil;
        
        @synchronized ([NSNull null]) {
            NSFileManager *asyncFileManager = [[NSFileManager alloc] init];
            urlForUbiquityContainerIdentifier = [[[asyncFileManager URLForUbiquityContainerIdentifier:nil] URLByAppendingPathComponent:@"Documents" isDirectory:YES] retain];
            if (urlForUbiquityContainerIdentifier != nil)
                [asyncFileManager createDirectoryAtURL:urlForUbiquityContainerIdentifier withIntermediateDirectories:NO attributes:nil error:nil];
            [asyncFileManager release];
        }
        
        didCheckUbiquityStatus = true;
    }
    
    return urlForUbiquityContainerIdentifier;
}

- (void)resetUbiquityStatus {
    [self endPollingMetadata];
    didCheckUbiquityStatus = false;
    if ([CloudMetadataManager urlForUbiquityContainerIdentifier] != nil && self.shouldMessage)
        [self startPollingMetadata];
}

- (void)startPollingMetadata {
    dispatch_async(managerQueue, ^{
        [metadataQuery disableUpdates];
        [metadataQuery stopQuery];
        [metadataQuery release];
        metadataQuery = nil;
        [metadataDictionary removeAllObjects];
    
        metadataQuery = [[NSMetadataQuery alloc] init];
        [metadataQuery setSearchScopes:[NSArray arrayWithObject:NSMetadataQueryUbiquitousDocumentsScope]];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(metadataQueryDidFinishGatheringNotification:) name:NSMetadataQueryDidFinishGatheringNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(metadataQueryDidUpdateNotification:) name:NSMetadataQueryDidUpdateNotification object:nil];
        
        [metadataQuery setPredicate:[NSPredicate predicateWithFormat:@"%K BEGINSWITH %@", NSMetadataItemPathKey, [[CloudMetadataManager urlForUbiquityContainerIdentifier] path]]];
        [metadataQuery performSelectorOnMainThread:@selector(startQuery) withObject:nil waitUntilDone:NO];
    });
}

- (void)endPollingMetadata {
    dispatch_async(managerQueue, ^{
        [metadataQuery disableUpdates];
        [metadataQuery stopQuery];
        [metadataQuery release];
        metadataQuery = nil;
        [metadataDictionary removeAllObjects];
    });
}


- (BOOL)shouldMessage {
    @synchronized(self) {
        return shouldMessage;
    }
}

- (void)setShouldMessage:(BOOL)value {
    @synchronized(self) {
        shouldMessage = value;
    }
    
    if ([CloudMetadataManager urlForUbiquityContainerIdentifier] != nil && self.shouldMessage)
        [self startPollingMetadata];
    else
        [self endPollingMetadata];
}


////////////////////////////////////////////
// NSMetadataQuery Notifications Handling //
////////////////////////////////////////////

#pragma mark NSMetadataQuery Notifications Handling

- (void)metadataQueryDidFinishGatheringNotification:(NSNotification *)notification {
    dispatch_async(managerQueue, ^{
        NSMetadataQuery *query = [notification object];
        if (query != metadataQuery)
            return;
        
        [metadataDictionary removeAllObjects];
        for (NSMetadataItem *item in metadataQuery.results)
            [metadataDictionary setObject:[item valueForAttribute:NSMetadataItemFSContentChangeDateKey] forKey:[item valueForAttribute:NSMetadataItemPathKey]];
    });
}

- (void)metadataQueryDidUpdateNotification:(NSNotification *)notification {
    dispatch_async(managerQueue, ^{
        NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
        
        NSMetadataQuery *query = [notification object];
        if (query != metadataQuery)
            return;
        
        NSMutableDictionary *items = [NSMutableDictionary dictionary];
        
        NSMutableArray *addedItems = [NSMutableArray array];
        NSMutableArray *changedItems = [NSMutableArray array];
        NSMutableArray *removedItems = [NSMutableArray array];
        
        // Look for added & changed items
        for (NSMetadataItem *item in metadataQuery.results) {
            NSString *itemPath = [item valueForAttribute:NSMetadataItemPathKey];
            
            if ([metadataDictionary objectForKey:itemPath] != nil) {
                if ([(NSDate *)[item valueForAttribute:NSMetadataItemFSContentChangeDateKey] compare:[metadataDictionary objectForKey:itemPath]] != NSOrderedSame)
                    [changedItems addObject:itemPath];
            } else
                [addedItems addObject:itemPath];
            
            [items setObject:[item valueForAttribute:NSMetadataItemFSContentChangeDateKey] forKey:[item valueForAttribute:NSMetadataItemPathKey]];
        }
        
        // Look for removed items
        for (NSString *path in metadataDictionary) {
            if ([items objectForKey:path] == nil)
                [removedItems addObject:path];
        }
        
        [metadataDictionary release];
        metadataDictionary = [items retain];
        
        unsigned long changeCount = (unsigned long)(addedItems.count + changedItems.count + removedItems.count);
        
        if (changeCount != 0) {
        NSMutableString *message = [NSMutableString stringWithFormat:@"%lu", changeCount];
        
        NSUInteger pathTrim = [[[CloudMetadataManager urlForUbiquityContainerIdentifier] path] length] + 1;
        
        for (NSString *path in addedItems)
            [message appendFormat:@":%@:0", [path substringFromIndex:pathTrim]];
        for (NSString *path in changedItems)
            [message appendFormat:@":%@:1", [path substringFromIndex:pathTrim]];
        for (NSString *path in removedItems)
            [message appendFormat:@":%@:2", [path substringFromIndex:pathTrim]];
        
        dispatch_async(dispatch_get_main_queue(),^ {
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
            UnitySendMessage("JCloudManager", "FileDidChange", [message UTF8String]);
#elif TARGET_OS_MAC
            if (messageCallbackPointer != 0) // Prevent BAD_ACCESS in case something goes horribly wrong
                (*((ManagedCallbackPointer *)messageCallbackPointer))([message UTF8String]);
#endif
        });
        }
        
        [pool drain];
    });
}


@end
