//
//  JCPDocument.m
//  jCloudPlugin
//
//  Created by Jérémie Di Prizio on 28/11/11.
//  Copyright (c) 2011-2013 jemast software.
//

#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
#import <UIKit/UIKit.h>
#elif TARGET_OS_MAC
#endif


#import "JCPDocument.h"
#import "CloudDocumentManager.h"


// Private properties & methods interface declaration
@interface JCPDocument ()

@property(readwrite, retain) NSURL *fileURL;
@property(readwrite, retain) NSDate *fileModificationDate;
@property (readwrite) JCPDocumentState documentState;
@property (readwrite) BOOL fileIsWritable;
@property (readwrite) BOOL fileIsDirectory;
@property (readwrite, retain) id fileData;
//@property (retain) NSOperationQueue *documentQueue;


- (void)closeDocumentWithNotification:(BOOL)notification;
- (void)updateChangeCount;
- (void)waitForWriter:(void (^)())completionHandler;


@end


@implementation JCPDocument

@synthesize fileURL, fileModificationDate, documentState, fileIsWritable, fileIsDirectory, fileData;


//////////////////////////////////////
// Initialization & Dealloc Methods //
//////////////////////////////////////

#pragma mark Initialization & Dealloc Methods

- (id)init {
    if ((self = [super init])) {
        // Start listening for application suspend & quit notifications in order to save documents just in time
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(shouldAutosaveImmediately) name:UIApplicationWillResignActiveNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(shouldAutosaveImmediately) name:UIApplicationWillTerminateNotification object:nil];
#elif TARGET_OS_MAC
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(shouldAutosaveImmediately) name:NSApplicationWillResignActiveNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(shouldAutosaveImmediately) name:NSApplicationWillTerminateNotification object:nil];
#endif
    }
    
    return self;
}

- (id)initWithFileURL:(NSURL *)url {
    if (url == nil)
        return self;
    
    if ((self = [self init])) {
        self.fileURL = url;
        self.fileData = [NSData data];
        documentState = JCPDocumentStateClosed;
        fileIsWritable = YES;
        fileIsDirectory = NO;
        
        // Prepare our mutexes
        changeCountTokenMutex = [[NSObject alloc] init];
        
        // Make sure we are coordinated from the get go
        [NSFileCoordinator addFilePresenter:self];
    }
    
    return self;
}

+ (id)documentWithFileURL:(NSURL *)url {
    return [[[JCPDocument alloc] initWithFileURL:url] autorelease];
}

- (id)initWithDirectoryURL:(NSURL *)url {
    if (url == nil)
        return self;
    
    if ((self = [self init])) {
        self.fileURL = url;
        self.fileData = [NSArray array];
        documentState = JCPDocumentStateClosed;
        fileIsWritable = YES;
        fileIsDirectory = YES;
        
        // Prepare our mutexes
        changeCountTokenMutex = [[NSObject alloc] init];
        
        // Make sure we are coordinated from the get go
        [NSFileCoordinator addFilePresenter:self];
    }
    
    return self;
}

+ (id)documentWithDirectoryURL:(NSURL *)url {
    return [[[JCPDocument alloc] initWithDirectoryURL:url] autorelease];
}

- (void)dealloc {
    // Stop observing notifications
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    // Clear memory
    self.fileURL = nil;
    self.fileModificationDate = nil;
    self.fileData = nil;
    
    [changeCountTokenMutex release];
    
    [super dealloc];
}


///////////////////////////////////
// Document Manipulation Methods //
///////////////////////////////////

#pragma mark Document Manipulation Methods

- (BOOL)existsWithError:(int *)error {
    // Coordinate reading
    NSFileCoordinator *fileCoordinator = [[NSFileCoordinator alloc] initWithFilePresenter:self];
    
    NSError *coordinatorError = nil;
    __block BOOL success;
    
    [fileCoordinator coordinateReadingItemAtURL:self.fileURL options:NSFileCoordinatorReadingWithoutChanges error:&coordinatorError byAccessor:^(NSURL *newURL) {
        BOOL fileExistsAtPath, isDirectory;
        fileExistsAtPath = [[[[NSFileManager alloc] init] autorelease] fileExistsAtPath:[newURL path] isDirectory:&isDirectory];
        if (fileExistsAtPath && (isDirectory == self.fileIsDirectory)) {
            success = YES;
        } else {
            success = NO;
        }
    }];
    
    [fileCoordinator release];
    
    // If we had an error coordinating, close document & notify
    if (coordinatorError) {
        [self closeDocumentWithNotification:YES];
        
        if (error != nil)
            *error = kCloudDocumentErrorNativeError;
        
        return NO;
    }
    
    if (error != nil)
        *error = kCloudDocumentErrorNone;
    
    return success;
}

- (NSDate *)modificationDate {
    // Coordinate reading
    NSFileCoordinator *fileCoordinator = [[NSFileCoordinator alloc] initWithFilePresenter:self];
    
    NSError *coordinatorError = nil;
    __block NSDate *modificationDate = nil;
    [fileCoordinator coordinateReadingItemAtURL:self.fileURL options:0 error:&coordinatorError byAccessor:^(NSURL *newURL) {
        // Read modification date
        NSError *attributesError = nil;
        NSDictionary *attributes = [[[[NSFileManager alloc] init] autorelease] attributesOfItemAtPath:[newURL path] error:&attributesError];
        
        // Did we succeed reading attributes?
        if (attributesError == nil) {
            modificationDate = [[attributes objectForKey:NSFileModificationDate] retain];
        }
    }];
    
    [fileCoordinator release];
    
    // If we had an error coordinating, close document & notify
    if (coordinatorError) {
        [self closeDocumentWithNotification:YES];
        return nil;
    }
    
    if (modificationDate != nil) {
        // Return modification date
        return [modificationDate autorelease];
    } else {
        // Close document with notification
        [self closeDocumentWithNotification:YES];
        return nil;
    }
}

- (BOOL)openDocument {
    // Coordinate reading
    NSFileCoordinator *fileCoordinator = [[NSFileCoordinator alloc] initWithFilePresenter:self];
    
    NSError *coordinatorError = nil;
    __block BOOL success;
    [fileCoordinator coordinateReadingItemAtURL:self.fileURL options:0 error:&coordinatorError byAccessor:^(NSURL *newURL) {
        // Read modification date
        NSError *attributesError = nil;
        NSDictionary *attributes = [[[[NSFileManager alloc] init] autorelease] attributesOfItemAtPath:[newURL path] error:&attributesError];
        
        // Did we succeed reading attributes?
        if (attributesError != nil) {
            // Close document with notification
            [self closeDocumentWithNotification:YES];
            
            // Failed
            success = NO;
        } else {
            // Set modification date
            if (fileModificationDate != nil && [(NSDate *)[attributes objectForKey:NSFileModificationDate] compare:fileModificationDate] == NSOrderedSame) {
                success = YES;
            } else {
                [self setFileModificationDate:[attributes objectForKey:NSFileModificationDate]];
                
                if (!self.fileIsDirectory) { // Are we dealing with a file ?
                    // Read from file
                    NSError *readError = nil;
                    self.fileData = [NSData dataWithContentsOfURL:newURL options:0 error:&readError];
                    if (self.fileData == nil)
                        self.fileData = [NSData data];
                    
                    if (readError == nil) {
                        success = YES;
                    } else {
                        success = NO;
                    }
                } else { // We're dealing with a directory
                    // Read contents of directory
                    NSError *readError = nil;
                    self.fileData = [[[[NSFileManager alloc] init] autorelease] contentsOfDirectoryAtURL:newURL includingPropertiesForKeys:nil options:(NSDirectoryEnumerationSkipsSubdirectoryDescendants | NSDirectoryEnumerationSkipsPackageDescendants) error:&readError];
                    if (self.fileData == nil)
                        self.fileData = [NSArray array];
                    
                    if (readError == nil) {
                        success = YES;
                    } else {
                        success = NO;
                    }
                }
            }
        }
    }];
    
    [fileCoordinator release];
    
    // If we had an error coordinating, close document & notify
    if (coordinatorError) {
        [self closeDocumentWithNotification:YES];
        return NO;
    }
    if (success) {
        // Set document state as normal and notify
        self.documentState = JCPDocumentStateNormal;
        [[NSNotificationCenter defaultCenter] postNotificationName:JCPDocumentStateChangedNotification object:self];
        
        // Call completion handler
        return YES;
    } else {
        // Close document with notification
        [self closeDocumentWithNotification:YES];
        
        // Call completion handler
        return NO;
    }
}

- (BOOL)closeDocument {
    // Do we have unsaved changes ? Save first !
    if ([self hasUnsavedChanges]) {
        // Save immediately
        [self saveDocument];
    }

    // Close document & notify
    [self closeDocumentWithNotification:NO];
    
    return YES;
}

- (BOOL)saveDocument {
    __block NSUInteger saveToken = 0;
    __block BOOL success, hasWriteError;
    __block NSDate *modificationDate;
    __block NSError *coordinatorError = nil;
    
    // Wait for file to be writable
    [self waitForWriter:^(void) {
        
        // We are writable and are guaranteed exclusive write time
        NSFileCoordinator *fileCoordinator = [[NSFileCoordinator alloc] initWithFilePresenter:self];
        
        // Get our save token
        if (!self.fileIsDirectory) { // Are we dealing with a file ?
            @synchronized(changeCountTokenMutex) {
                saveToken = changeCountToken;
            }
        }
        
        [fileCoordinator coordinateWritingItemAtURL:self.fileURL options:0 error:&coordinatorError byAccessor:^(NSURL *newURL) {
            NSError *writeError = nil;
            
            if (!self.fileIsDirectory) { // Are we dealing with a file ?
                if ([self.fileData writeToURL:newURL options:NSDataWritingAtomic error:&writeError]) {
                    // Read modification date
                    NSError *attributesError = nil;
                    NSDictionary *attributes = [[[[NSFileManager alloc] init] autorelease] attributesOfItemAtPath:[newURL path] error:&attributesError];
                    
                    // Did we succeed reading attributes?
                    if (attributesError != nil) {
                        success = NO;
                        hasWriteError = NO;
                    } else {
                        success = YES;
                        hasWriteError = NO;
                        modificationDate = [[attributes objectForKey:NSFileModificationDate] retain];
                    }
                } else {
                    //if (writeError)
                    //    NSLog(@"JCPDocument :: saveWithCompletionHandler :: writeToURL error %@", writeError);
                    
                    success = NO;
                    hasWriteError = YES;
                    
                }
            } else { // Or a directory ?
                if ([[[[NSFileManager alloc] init] autorelease] createDirectoryAtURL:newURL withIntermediateDirectories:NO attributes:nil error:&writeError]) {
                    // Read modification date
                    NSError *attributesError = nil;
                    NSDictionary *attributes = [[[[NSFileManager alloc] init] autorelease] attributesOfItemAtPath:[newURL path] error:&attributesError];
                    
                    // Did we succeed reading attributes?
                    if (attributesError != nil) {
                        success = NO;
                        hasWriteError = NO;
                    } else {
                        success = YES;
                        hasWriteError = NO;
                        modificationDate = [[attributes objectForKey:NSFileModificationDate] retain];
                    }
                } else {
                    //if (writeError)
                    //    NSLog(@"JCPDocument :: saveWithCompletionHandler :: createDirectoryAtURL error %@", writeError);
                    
                    success = NO;
                    hasWriteError = YES;
                }
            }
        }];
        
        [fileCoordinator release];
    }];
    
    // If we had an error coordinating, close document & notify
    if (coordinatorError) {
        [self closeDocumentWithNotification:YES];
        return NO;
        //dispatch_async(callerQueue, ^(void) { completionHandler(NO); });
    }
    
    if (success) {
        if (!self.fileIsDirectory) { // Are we dealing with a file ?
            // Update change count token if our save token matches
            @synchronized(changeCountTokenMutex) {
                if (changeCountToken == saveToken)
                    changeCountToken = 0;
            }
        }
        
        // Set file modification date
        [self setFileModificationDate:[modificationDate autorelease]];
        
        // Set document state as normal and notify
        self.documentState = JCPDocumentStateNormal;
        [[NSNotificationCenter defaultCenter] postNotificationName:JCPDocumentStateChangedNotification object:self];
        
        // Call completion handler
        return YES;
    } else {
        if (hasWriteError) {
            // If we have a write error, set document state as saving error & notify
            self.documentState = JCPDocumentStateSavingError;
            [[NSNotificationCenter defaultCenter] postNotificationName:JCPDocumentStateChangedNotification object:self];
            
            // Call completion handler
            return NO;
        } else {
            // Close document with notification
            [self closeDocumentWithNotification:YES];
            
            // Call completion handler
            return NO;
        }
    }
}

- (BOOL)deleteDocument {
    __block BOOL success;
    __block NSError *coordinatorError = nil;

    // Wait for file to be writable
    [self waitForWriter:^(void) {
        // We are writable and are guaranteed exclusive write time
        NSFileCoordinator *fileCoordinator = [[NSFileCoordinator alloc] initWithFilePresenter:self];
        
        [fileCoordinator coordinateWritingItemAtURL:self.fileURL options:NSFileCoordinatorWritingForDeleting error:&coordinatorError byAccessor:^(NSURL *newURL) {
            // Delete immediately
            NSError *removeError = nil;
            BOOL removeSuccess = [[[[NSFileManager alloc] init] autorelease] removeItemAtURL:newURL error:&removeError];
            
            if ((removeError == nil) && removeSuccess) {
                success = YES;
            } else {
                success = NO;
            }
        }];
        
        // Update change count to 0, no autosave ; if we are dealign with a file
        if (!self.fileIsDirectory) {
            @synchronized(changeCountTokenMutex) {
                changeCountToken = 0;
            }
        }
        
        [fileCoordinator release];
    }];
    
    // Close document with notification
    [self closeDocumentWithNotification:YES];
    
    // If we had an error coordinating, failure
    if (coordinatorError)
        return NO;
    
    return success;
}

- (BOOL)copyDocumentToURL:(NSURL *)destinationURL overwrite:(BOOL)overwrite error:(int *)error {
    // Coordinate reading
    NSFileCoordinator *fileCoordinator = [[NSFileCoordinator alloc] initWithFilePresenter:self];
    
    NSError *coordinatorError = nil;
    __block BOOL success;
    [fileCoordinator coordinateReadingItemAtURL:self.fileURL options:0 writingItemAtURL:destinationURL options:NSFileCoordinatorWritingForReplacing error:&coordinatorError byAccessor:^(NSURL *newReadingURL, NSURL *newWritingURL) {
        BOOL fileExistsAtPath, isDirectory;
        BOOL canProceed = YES;
        NSFileManager *fileManager = [[NSFileManager alloc] init];
        fileExistsAtPath = [fileManager fileExistsAtPath:[newWritingURL path] isDirectory:&isDirectory];
        if (fileExistsAtPath && (isDirectory == self.fileIsDirectory)) {
            // Destination already exists, attempt to remove if we asked for overwrite
            if (overwrite) {
                NSError *removeError = nil;
                if (![fileManager removeItemAtURL:newWritingURL error:&removeError]) {
                    canProceed = NO;
                    if (error != nil)
                        *error = kCloudDocumentErrorOverwriteError;
                }
            } else {
                canProceed = NO;
                if (error != nil)
                    *error = kCloudDocumentErrorOverwriteError;
            }
        }
        
        // Make sure destination directories exist
        if (canProceed) {
            NSError *directoryError = nil;
            //if (self.fileIsDirectory)
            //    canProceed = [fileManager createDirectoryAtURL:newWritingURL withIntermediateDirectories:YES attributes:nil error:&directoryError];
            //else
                canProceed = [fileManager createDirectoryAtURL:[newWritingURL URLByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:&directoryError];
            
            if (directoryError != nil)
                canProceed = NO;
        }
        
        // We're now sure destination does not exist, copy
        NSError *copyError = nil;
        if (canProceed && [fileManager copyItemAtURL:newReadingURL toURL:newWritingURL error:&copyError]) {
            success = YES;
            if (error != nil)
                *error = kCloudDocumentErrorNone;
        } else {
            success = NO;
            if (error != nil)
                *error = kCloudDocumentErrorNativeError;
        }
        
        // Release
        [fileManager release];
    }];
    
    [fileCoordinator release];
    
    // If we had an error coordinating, close document & notify
    if (coordinatorError) {
        [self closeDocumentWithNotification:YES];
        
        if (error != nil)
            *error = kCloudDocumentErrorPluginError;
        
        return NO;
    }
    
    return success;
}

- (BOOL)moveDocumentToURL:(NSURL *)destinationURL overwrite:(BOOL)overwrite error:(int *)error {
    // Coordinate reading
    NSFileCoordinator *fileCoordinator = [[NSFileCoordinator alloc] initWithFilePresenter:self];
    
    NSError *coordinatorError = nil;
    __block BOOL success;
    [fileCoordinator coordinateReadingItemAtURL:self.fileURL options:0 writingItemAtURL:destinationURL options:NSFileCoordinatorWritingForReplacing error:&coordinatorError byAccessor:^(NSURL *newReadingURL, NSURL *newWritingURL) {
        BOOL fileExistsAtPath, isDirectory;
        BOOL canProceed = YES;
        NSFileManager *fileManager = [[[NSFileManager alloc] init] autorelease];
        fileExistsAtPath = [fileManager fileExistsAtPath:[newWritingURL path] isDirectory:&isDirectory];
        if (fileExistsAtPath && (isDirectory == self.fileIsDirectory)) {
            // Destination already exists, attempt to remove if we asked for overwrite
            if (overwrite) {
                NSError *removeError = nil;
                if (![fileManager removeItemAtURL:newWritingURL error:&removeError]) {
                    canProceed = NO;
                    if (error != nil)
                        *error = kCloudDocumentErrorOverwriteError;
                }
            } else {
                canProceed = NO;
                if (error != nil)
                    *error = kCloudDocumentErrorOverwriteError;
            }
        }
        
        // Make sure destination directories exist
        if (canProceed) {
            NSError *directoryError = nil;
            //if (self.fileIsDirectory)
            //    canProceed = [fileManager createDirectoryAtURL:newWritingURL withIntermediateDirectories:YES attributes:nil error:&directoryError];
            //else
                canProceed = [fileManager createDirectoryAtURL:[newWritingURL URLByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:&directoryError];
        
            if (directoryError != nil)
                canProceed = NO;
        }
        
        // We're now sure destination does not exist, move
        NSError *moveError = nil;
        if (canProceed && [fileManager moveItemAtURL:newReadingURL toURL:newWritingURL error:&moveError]) {
            success = YES;
            if (error != nil)
                *error = kCloudDocumentErrorNone;
        } else {
            success = NO;
            if (error != nil)
                *error = kCloudDocumentErrorNativeError;
        }
    }];
    
    [fileCoordinator release];
    
    // If we had an error coordinating, close document & notify
    if (coordinatorError) {
        [self closeDocumentWithNotification:YES];
        
        if (error != nil)
            *error = kCloudDocumentErrorPluginError;
        
        return NO;
    }
    
    return success;
}

- (BOOL)removeOtherVersions {
    __block BOOL success, hasWriteError;
    __block NSError *coordinatorError = nil;
    
    // Wait for file to be writable
    [self waitForWriter:^(void) {
        
        // We are writable and are guaranteed exclusive write time
        NSFileCoordinator *fileCoordinator = [[NSFileCoordinator alloc] initWithFilePresenter:self];
        
        [fileCoordinator coordinateWritingItemAtURL:self.fileURL options:0 error:&coordinatorError byAccessor:^(NSURL *newURL) {
            NSError *writeError = nil;
            
            if (!self.fileIsDirectory) { // Are we dealing with a file ?
                if ([NSFileVersion removeOtherVersionsOfItemAtURL:newURL error:&writeError]) {
                        success = YES;
                        hasWriteError = NO;
                } else {
                    //if (writeError)
                    //    NSLog(@"JCPDocument :: removeOtherVersions :: removeOtherVersionsOfItemAtURL error %@", writeError);
                    
                    success = NO;
                    hasWriteError = (writeError != nil);
                    
                }
            }
        }];
        
        [fileCoordinator release];
    }];
    
    // If we had an error coordinating, close document & notify
    if (coordinatorError) {
        [self closeDocumentWithNotification:YES];
        return NO;
    }
    
    if (success) {
        // Set document state as normal and notify
        self.documentState = JCPDocumentStateNormal;
        [[NSNotificationCenter defaultCenter] postNotificationName:JCPDocumentStateChangedNotification object:self];
        return YES;
    } else {
        if (hasWriteError) {
            // If we have a write error, set document state as saving error & notify
            self.documentState = JCPDocumentStateSavingError;
            [[NSNotificationCenter defaultCenter] postNotificationName:JCPDocumentStateChangedNotification object:self];
            return NO;
        } else {
            // Close document with notification
            [self closeDocumentWithNotification:YES];
            return NO;
        }
    }
}

- (BOOL)setContents:(NSData *)data {
    // Not happening for directories
    if (self.fileIsDirectory)
        return NO;
    
    // Uncomment to prevent data writing while file is not writable -- we don't want that, writing operations will just wait for writer
    //if (self.fileIsWritable == NO)
    //    return NO;
    
    self.fileData = data;//[NSMutableData dataWithData:data];
    [self updateChangeCount];
    
    return YES;
}

- (void)shouldAutosaveImmediately {
    // Do we have unsaved changes ?
    if ([self hasUnsavedChanges]) // Save immediately
        [self saveDocument];
}


/////////////////////////////
// Internal Helper Methods //
/////////////////////////////

#pragma mark Internal Helper Methods

- (void)closeDocumentWithNotification:(BOOL)notification {
    // Remove as file presenter
    [NSFileCoordinator removeFilePresenter:self];
    
    // Close document
    self.fileURL = nil;
    self.fileModificationDate = nil;
    self.documentState = JCPDocumentStateClosed;
    self.fileData = nil;
    self.fileIsWritable = NO;
    self.fileIsDirectory = NO;
    @synchronized(changeCountTokenMutex) {
        changeCountToken = 0;
    }
    
    // Notify file closed
    if (notification)
        [[NSNotificationCenter defaultCenter] postNotificationName:JCPDocumentStateChangedNotification object:self]; //dispatch_async(managerQueue, ^{ [[NSNotificationCenter defaultCenter] postNotificationName:JCPDocumentStateChangedNotification object:self]; });
}

- (BOOL)hasUnsavedChanges {
    if (!self.fileIsDirectory) { // Are we dealing with a file ?
        // If token is not 0, we have unsaved changes
        @synchronized(changeCountTokenMutex) {
            return changeCountToken != 0;
        }
    }
    
    // Directories have no unsaved changes
    return NO;
}

- (void)updateChangeCount {
    if (!self.fileIsDirectory) { // Are we dealing with a file ?
        // Update token
        @synchronized(changeCountTokenMutex) {
            changeCountToken++;
        }
    }
}

- (void)waitForWriter:(void (^)())completionHandler {
    // If file is already writable, call our completion handler immediately
    if (self.fileIsWritable)
        return completionHandler();
    
    // Get caller queue
    dispatch_queue_t callerQueue = dispatch_get_current_queue();
    
    // Create a timer that will periodically check for writer
    dispatch_source_t timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0));
    
    // Prepare a 100ms timer with 10ms leeway
    dispatch_source_set_timer(timer, dispatch_walltime(NULL, 100ull * NSEC_PER_MSEC), 100ull * NSEC_PER_MSEC, 10ull * NSEC_PER_MSEC);
    dispatch_source_set_event_handler(timer, ^(void) {
        if (self.fileIsWritable) {
            // Cancel and release timer
            dispatch_source_cancel(timer);
            dispatch_release(timer);
            dispatch_async(callerQueue, ^(void) { completionHandler(); });
        }
    });
    
    // Fire timer
    dispatch_resume(timer);
}


/////////////////////////////////////////////
// NSFilePresenter Protocol Implementation //
/////////////////////////////////////////////
#pragma mark NSFilePresenter Protocol Implementation

- (NSURL *)presentedItemURL {
    return self.fileURL;
}

- (NSOperationQueue *)presentedItemOperationQueue {
    static NSOperationQueue *concurrentQueue = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        concurrentQueue = [[NSOperationQueue alloc] init];
    });
    
    return concurrentQueue;
}

- (void)relinquishPresentedItemToReader:(void (^)(void (^reacquirer)(void))) reader {
    // Prepare for another object to read the file.
    self.fileIsWritable = NO;
    
    // Set document state as editing disabled & notify
    //self.documentState = JCPDocumentStateEditingDisabled;
    //dispatch_async(managerQueue, ^{ [[NSNotificationCenter defaultCenter] postNotificationName:JCPDocumentStateChangedNotification object:self]; });
    
    // Now let the reader know that it can have the file.
    // But pass a reacquisition block so that this object
    // can update itself when the reader is done.
    reader(^{
        self.fileIsWritable = YES;
        
        // Set document state as normal & notify
        //self.documentState = JCPDocumentStateNormal;
        //dispatch_async(managerQueue, ^{ [[NSNotificationCenter defaultCenter] postNotificationName:JCPDocumentStateChangedNotification object:self]; });
    });
}

- (void)relinquishPresentedItemToWriter:(void (^)(void (^reacquirer)(void))) writer {
    // Prepare for another object to write to the file.
    self.fileIsWritable = NO;
    
    // Set document state as editing disabled & notify
    //self.documentState = JCPDocumentStateEditingDisabled;
    //dispatch_async(managerQueue, ^{ [[NSNotificationCenter defaultCenter] postNotificationName:JCPDocumentStateChangedNotification object:self]; });
    
    // Now let the writer know that it can have the file.
    // But pass a reacquisition block so that this object
    // can update itself when the writer is done.
    writer(^{
        self.fileIsWritable = YES;
        
        // Set document state as normal & notify
        //self.documentState = JCPDocumentStateNormal;
        //dispatch_async(managerQueue, ^{ [[NSNotificationCenter defaultCenter] postNotificationName:JCPDocumentStateChangedNotification object:self]; });
    });
}

- (void)savePresentedItemChangesWithCompletionHandler:(void (^)(NSError *errorOrNil))completionHandler {
    // We're not actively modifying directories
    if (self.fileIsDirectory)
        return completionHandler(nil);
    
    // Save immediately if we have unsaved changes
    NSError *writeError = nil;
    if ([self hasUnsavedChanges]) {
        [self.fileData writeToURL:self.fileURL options:NSDataWritingAtomic error:&writeError];
        
        // If we have a write error, set document state as saving error & notify
        if (writeError) {
            self.documentState = JCPDocumentStateSavingError;
            [[NSNotificationCenter defaultCenter] postNotificationName:JCPDocumentStateChangedNotification object:self]; //dispatch_async(managerQueue, ^{ [[NSNotificationCenter defaultCenter] postNotificationName:JCPDocumentStateChangedNotification object:self]; });
        }
    }
    
    // Call completion handler
    completionHandler(writeError);
}

- (void)accommodatePresentedItemDeletionWithCompletionHandler:(void (^)(NSError *errorOrNil))completionHandler {
    // Close document
    [self closeDocumentWithNotification:YES];
    
    // Call completion handler
    completionHandler(nil);
}

- (void)presentedItemDidMoveToURL:(NSURL *)newURL {
    // Set our new URL
    self.fileURL = newURL;
}

- (void)presentedItemDidChange {
    // Calling openWithCompletionHandler will force a re-read
    [self openDocument];
}

- (void)accommodatePresentedSubitemDeletionAtURL:(NSURL *)url completionHandler:(void (^)(NSError *errorOrNil))completionHandler {
    // Calling openWithCompletionHandler will force a re-read
    [self openDocument];
    
    // Though we can call the completion handler immediately
    completionHandler(nil);
}



@end
