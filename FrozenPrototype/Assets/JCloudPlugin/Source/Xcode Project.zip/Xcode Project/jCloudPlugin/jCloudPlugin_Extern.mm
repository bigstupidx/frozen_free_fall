//
//  jCloudPlugin_Extern.mm
//  jCloudPlugin
//
//  Created by Jérémie Di Prizio on 04/11/11.
//  Copyright (c) 2011-2013 jemast software.
//


#import "jCloudPlugin_Extern.h"

#import <Foundation/Foundation.h>
#import "CloudDocumentManager.h"
#import "CloudDataManager.h"
#import "CloudMetadataManager.h"


/////////////////////////////////////
// CLOUD DOCUMENT EXTERN FUNCTIONS //
/////////////////////////////////////

#pragma mark Cloud Document Extern Functions

// PrepareCloudItem: instantiate a cloud document manager with given path, return a unique identifier
int PrepareCloudItem(const char *path, bool isDirectory) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int result = [[jCloudPlugin sharedInstance] prepareCloudDocumentManagerAtPath:[NSString stringWithUTF8String:path] isDirectory:isDirectory];
    [pool drain];
    return result;
}

// DismissCloudItem: tell plugin we don't use that item anymore and that it can safely be dismissed
bool DismissCloudItem(int uid) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    bool result = [[jCloudPlugin sharedInstance] dismissCloudDocumentManagerWithUniqueIdentifier:[NSNumber numberWithInt:uid]];
    [pool drain];
    return result;
}

// GetCloudItemState: returns cloud document manager state
int GetCloudItemState(int uid) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int result = (int)[[jCloudPlugin sharedInstance] getStateForCloudDocumentManagerWithUniqueIdentifier:[NSNumber numberWithInt:uid]];
    [pool drain];
    return result;
}

// CreateOrOpenCloudItem: async procedure to create or open a cloud item (file or directory)
bool CreateOrOpenCloudItem(int uid) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    bool result = [[jCloudPlugin sharedInstance] createOrOpenCloudDocumentManagerWithUniqueIdentifier:[NSNumber numberWithInt:uid]];
    [pool drain];
    return result;
}

// CreateCloudItem: async procedure to create a cloud item (file or directory)
bool CreateCloudItem(int uid) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    bool result = [[jCloudPlugin sharedInstance] createCloudDocumentManagerWithUniqueIdentifier:[NSNumber numberWithInt:uid]];
    [pool drain];
    return result;
}

// OpenCloudItem: async procedure to open a cloud item (file or directory)
bool OpenCloudItem(int uid) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    bool result = [[jCloudPlugin sharedInstance] openCloudDocumentManagerWithUniqueIdentifier:[NSNumber numberWithInt:uid]];
    [pool drain];
    return result;
}

// DeleteCloudItem: async procedure to delete a cloud item (file or directory)
bool DeleteCloudItem(int uid, char* deleted) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    bool result = [[jCloudPlugin sharedInstance] deleteCloudDocumentManagerWithUniqueIdentifier:[NSNumber numberWithInt:uid] deletedPointer:deleted];
    [pool drain];
    return result;
}

// WriteCloudItemContents: works for files only, replaces content with bytes passed to this function
bool WriteCloudItemContents(void *bytes, int length, int uid) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    bool result = [[jCloudPlugin sharedInstance] writeContents:[NSData dataWithBytesNoCopy:bytes length:length freeWhenDone:NO] toCloudDocumentManagerWithUniqueIdentifier:[NSNumber numberWithInt:uid]];
    [pool drain];
    return result;
}

// ReadCloudItemContents: files will return bytes, directories will return a list of files and subdirectories
int ReadCloudItemContents(int uid, NSInteger *bytes) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    NSData *contents = [[jCloudPlugin sharedInstance] readContentsOfCloudDocumentManagerWithUniqueIdentifier:[NSNumber numberWithInt:uid]];
    
    // Check that we have contents read
    if (contents == nil) {
        [pool drain];
        return -1;
    }
    
    // Return this content
    void *contentsBytes = malloc(contents.length);
    [contents getBytes:contentsBytes length:contents.length];
    *bytes = (NSInteger)contentsBytes;
    int result = (int)contents.length;
    [pool drain];
    return result;
}

// SetPersistentDataPath: used to pass Unity's path for persistent data as a fallback
void SetPersistentDataPath(const char *path) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [CloudDocumentManager setPersistentDataPath:[NSString stringWithUTF8String:path]];
    [CloudDataManager setPersistentDataPath:[NSString stringWithUTF8String:path]];
    [pool drain];
}

// GetCloudDirectoryPath: get cloud full path -- CURRENTLY UNUSED
bool GetCloudDirectoryPath(NSInteger *value) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    // Attempt to get iCloud URL
    NSURL *directoryURL = [CloudDocumentManager urlForUbiquityContainerIdentifier];
    
    // iCloud isn't available, get our local fallback URL
    if (directoryURL == nil)
        directoryURL = [CloudDocumentManager documentsDirectoryURL];
    
    // Get our cloud directory path (could be local if iCloud isn't available)
    const char *returnValue = [directoryURL.path UTF8String];
    
    // Set value and return valid
    *value = (NSInteger)returnValue;
    
    [pool drain];
    return YES;
}

// GetCloudItemExistence: async procedure to get if file or directory exists
bool GetCloudItemExistence(int uid, char* exists) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    bool result = [[jCloudPlugin sharedInstance] getExistenceOfCloudDocumentWithUniqueIdentifier:[NSNumber numberWithInt:uid] existsPointer:exists];
    [pool drain];
    return result;
}

// GetCloudItemModificationDate: async procedure to get file or directory last modification date
bool GetCloudItemModificationDate(int uid, uint64_t *modificationDate) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    bool result = [[jCloudPlugin sharedInstance] getModificationDateOfCloudDocumentWithUniqueIdentifier:[NSNumber numberWithInt:uid] modificationDatePointer:modificationDate];
    [pool drain];
    return result;
}

// CopyCloudItem: async procedure that copies file or directory to destination path
bool CopyCloudItem(int uid, const char *destinationPath, bool overwrite) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    bool result = [[jCloudPlugin sharedInstance] copyCloudDocumentWithUniqueIdentifier:[NSNumber numberWithInt:uid] destination:[NSString stringWithUTF8String:destinationPath] overwrite:overwrite];
    [pool drain];
    return result;
}

// MoveCloudItem: async procedure that copies file or directory to destination path
bool MoveCloudItem(int uid, const char *destinationPath, bool overwrite) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    bool result = [[jCloudPlugin sharedInstance] moveCloudDocumentWithUniqueIdentifier:[NSNumber numberWithInt:uid] destination:[NSString stringWithUTF8String:destinationPath] overwrite:overwrite];
    [pool drain];
    return result;
}

// CloudItemHasVersions
bool CloudItemHasConflictVersions(int uid, char* conflict) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    bool result = [[jCloudPlugin sharedInstance] getHasConflictVersionsOfCloudDocumentWithUniqueIdentifier:[NSNumber numberWithInt:uid] conflictPointer:conflict];
    [pool drain];
    return result;
}

// CloudItemFetchAllVersions
bool CloudItemFetchAllVersions(int uid, JCloudDocumentVersions *versions) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    bool result = [[jCloudPlugin sharedInstance] getAllVersionsOfCloudDocumentWithUniqueIdentifier:[NSNumber numberWithInt:uid] versions:versions];
    [pool drain];
    return result;
}

// OpenCloudItem: open a cloud item (file only) with a specific version identifier
bool OpenCloudItemWithVersionIdentifier(int uid, void *versionIdentifier, int versionIdentifierLength) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    NSData *versionIdentifierData = [NSData dataWithBytesNoCopy:versionIdentifier length:versionIdentifierLength freeWhenDone:NO];
    bool result = [[jCloudPlugin sharedInstance] openCloudDocumentManagerWithUniqueIdentifier:[NSNumber numberWithInt:uid] versionIdentifier:versionIdentifierData];
    [pool drain];
    return result;
}

// OpenCloudItem: resolves iCloud conflict by picking a file version
bool PickCloudItemWithVersionIdentifier(int uid, void *versionIdentifier, int versionIdentifierLength, const char* versionsHash) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    NSData *versionIdentifierData = [NSData dataWithBytesNoCopy:versionIdentifier length:versionIdentifierLength freeWhenDone:NO];
    NSString *md5Hash = [NSString stringWithUTF8String:versionsHash];
    bool result = [[jCloudPlugin sharedInstance] pickCloudDocumentManagerWithUniqueIdentifier:[NSNumber numberWithInt:uid] versionsHash:md5Hash versionIdentifier:versionIdentifierData];
    [pool drain];
    return result;
}

// This is used for OSX callbacks to managed code
void SetStateChangeCallbackPointer(NSInteger pointer) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [[jCloudPlugin sharedInstance] setStateChangeCallbackPointer:pointer];
    [pool drain];
}

// This is used for OSX callbacks to managed code
void SetStatusChangeCallbackPointer(NSInteger pointer) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [[jCloudPlugin sharedInstance] setStatusChangeCallbackPointer:pointer];
    [pool drain];
}

// This is used for OSX callbacks to managed code
void SetProgressChangeCallbackPointer(NSInteger pointer) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [[jCloudPlugin sharedInstance] setProgressChangeCallbackPointer:pointer];
    [pool drain];
}

void CloudMetadataSetShouldMessage(bool shouldMessage) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [[CloudMetadataManager sharedInstance] setShouldMessage:shouldMessage];
    [pool drain];
}

// This is used for OSX callbacks to managed code
void CloudMetadataSetCallbackPointer(NSInteger pointer) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [[CloudMetadataManager sharedInstance] setMessageCallbackPointer:pointer];
    [pool drain];
}

/////////////////////////////////
// CLOUD DATA EXTERN FUNCTIONS //
/////////////////////////////////

#pragma mark Cloud Data Extern Functions

// CloudData uses iCloud KVStore or NSUserDefaults as fallback
// All the methods next match PlayerPrefs functionnalities


void CloudDataSetInt(const char *key, int value) {
    // Failsafe
    if (key == nil)
        return;

    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [[CloudDataManager sharedInstance] setInt:value forKey:[NSString stringWithUTF8String:key]];
    [pool drain];
}

bool CloudDataGetInt(const char *key, int *value) {
    // Failsafe
    if (key == nil)
        return NO;
    
    // Check if this key exists
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    NSInteger returnValue;
    if (![[CloudDataManager sharedInstance] getIntForKey:[NSString stringWithUTF8String:key] value:&returnValue]) {
        [pool drain];
        return NO;
    }
    
    // It exists, set value and return valid
    *value = (int)returnValue;
    
    [pool drain];
    return YES;
}

void CloudDataSetFloat(const char *key, float value) {
    // Failsafe
    if (key == nil)
        return;

    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [[CloudDataManager sharedInstance] setFloat:value forKey:[NSString stringWithUTF8String:key]];
    [pool drain];
}

bool CloudDataGetFloat(const char *key, float *value) {
    // Failsafe
    if (key == nil)
        return NO;

    // Check if this key exists
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    float returnValue;
    if (![[CloudDataManager sharedInstance] getFloatForKey:[NSString stringWithUTF8String:key] value:&returnValue]) {
        [pool drain];
        return NO;
    }
    
    // It exists, set value and return valid
    *value = returnValue;
    
    [pool drain];
    return YES;
}

void CloudDataSetString(const char *key, const char *value) {
    // Failsafe
    if (key == nil)
        return;
    
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    if (value == nil) {
        // Set null is delete
        [[CloudDataManager sharedInstance] deleteKey:[NSString stringWithUTF8String:key]];
    } else {
        // Set value
        [[CloudDataManager sharedInstance] setString:[NSString stringWithUTF8String:value] forKey:[NSString stringWithUTF8String:key]];
    }

    [pool drain];
}

bool CloudDataGetString(const char *key, NSInteger *value) {
    // Failsafe
    if (key == nil)
        return NO;

    // Check if this key exists
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    NSString *returnValue;
    if (![[CloudDataManager sharedInstance] getStringForKey:[NSString stringWithUTF8String:key] value:&returnValue]) {
        [pool drain];
        return NO;
    }
    
    // It exists, set value and return valid
    char *valueContents = (char *)malloc([returnValue lengthOfBytesUsingEncoding:NSUTF8StringEncoding]+1);
    strcpy((char *)valueContents, [returnValue UTF8String]);
    *value = (NSInteger)valueContents;
    
    [pool drain];
    return YES;
}

bool CloudDataHasKey(const char *key) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    bool result = [[CloudDataManager sharedInstance] hasKey:[NSString stringWithUTF8String:key]];
    [pool drain];
    return result;
}

void CloudDataDeleteKey(const char *key) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [[CloudDataManager sharedInstance] deleteKey:[NSString stringWithUTF8String:key]];
    [pool drain];
}

void CloudDataDeleteAll() {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [[CloudDataManager sharedInstance] deleteAll];
    [pool drain];
}

void CloudDataSave() {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [[CloudDataManager sharedInstance] save];
    [pool drain];
}

void CloudDataSetShouldMessage(bool shouldMessage) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [[CloudDataManager sharedInstance] setShouldMessage:shouldMessage];
    [pool drain];
}

// This is used for OSX callbacks to managed code
void CloudDataSetCallbackPointer(NSInteger pointer) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [[CloudDataManager sharedInstance] setMessageCallbackPointer:pointer];
    [pool drain];
}


////////////////////////////////////
// CLOUD POLLING EXTERN FUNCTIONS //
////////////////////////////////////

#pragma mark Cloud Polling Extern Functions

// GetUbiquitousContainerAvailability: returns wether iCloud's ubiquitous container is available or not
bool GetUbiquitousContainerAvailability() {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    bool result = ([CloudDocumentManager urlForUbiquityContainerIdentifier] != nil);
    [pool drain];
    return result;
}

// GetUbiquitousStoreAvailability: returns wether iCloud's ubiquitous key-value store is available or not
bool GetUbiquitousStoreAvailability() {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    bool result = [[CloudDataManager sharedInstance] isCloudAvailable];
    [pool drain];
    return result;
}

// Will force rechecking if iCloud is availabe for documents
void ResetUbiquityStatus() {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [[CloudMetadataManager sharedInstance] resetUbiquityStatus];
    [CloudDocumentManager resetUbiquityStatus];
    [pool drain];
}


/////////////////////////////////
// MEMORY MANAGEMENT FUNCTIONS //
/////////////////////////////////

// Cannot trust freeing unmanaged memory in managed code
void FreeMemory(NSInteger *pointer) {
    if (pointer == nil)
        return;
    
    free(pointer);
}

///////////////////
// VARIOUS STUFF //
///////////////////

BOOL IsJailbroken() {
#if !TARGET_OS_IPHONE
    return NO;
#else
    static BOOL done = NO;
    static BOOL jailbroken = NO;
    
    if (done == NO) {
        FILE *f = fopen("/bin/bash", "r");
    
        if (errno == ENOENT) {
            jailbroken = NO;
        } else {
            jailbroken = YES;
        }
        
        fclose(f);
        done = YES;
    }
    
    return jailbroken;
#endif
}