//
//  jCloudPlugin.h
//  jCloudPlugin
//
//  Created by Jérémie Di Prizio on 05/11/11.
//  Copyright (c) 2011-2013 jemast software.
//

#import <Foundation/Foundation.h>
#import "CloudDocumentManager.h"


typedef struct JCloudDocumentVersions {
    NSInteger *versionsHash;
    NSInteger **versionsUniqueIdentifiers;
    NSInteger *versionsUniqueIdentifiersLengthes;
    uint64_t *versionsModificationDates;
    uint8_t *versionsIsCurrent;
    NSInteger versionsCount;
} JCloudDocumentVersions;


@interface jCloudPlugin : NSObject <CloudDocumentManagerDelegate> {
    uint32_t                currentIdentifier;
    NSMutableDictionary     *cloudDocumentManagerDictionary;
    NSMutableDictionary     *cloudDocumentPathDictionary;
    NSInteger               stateChangeCallbackPointer;
    NSInteger               statusChangeCallbackPointer;
    NSInteger               progressChangeCallbackPointer;
}

@property (readwrite) NSInteger stateChangeCallbackPointer;
@property (readwrite) NSInteger statusChangeCallbackPointer;
@property (readwrite) NSInteger progressChangeCallbackPointer;

+ (jCloudPlugin *)sharedInstance;

- (int)prepareCloudDocumentManagerAtPath:(NSString *)path isDirectory:(BOOL)directory;
- (BOOL)dismissCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier;
- (NSInteger)getStateForCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier;
- (BOOL)createOrOpenCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier;
- (BOOL)createCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier;
- (BOOL)openCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier;
- (BOOL)deleteCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier deletedPointer:(char *)deletedPointer;
- (BOOL)writeContents:(NSData *)contents toCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier;
- (NSData *)readContentsOfCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier;
- (BOOL)getExistenceOfCloudDocumentWithUniqueIdentifier:(NSNumber *)uniqueIdentifier existsPointer:(char *)existsPointer;
- (BOOL)getModificationDateOfCloudDocumentWithUniqueIdentifier:(NSNumber *)uniqueIdentifier modificationDatePointer:(uint64_t *)modificationDatePointer;
- (BOOL)copyCloudDocumentWithUniqueIdentifier:(NSNumber *)uniqueIdentifier destination:(NSString *)path overwrite:(BOOL)overwrite;
- (BOOL)moveCloudDocumentWithUniqueIdentifier:(NSNumber *)uniqueIdentifier destination:(NSString *)path overwrite:(BOOL)overwrite;
- (BOOL)getHasConflictVersionsOfCloudDocumentWithUniqueIdentifier:(NSNumber *)uniqueIdentifier conflictPointer:(char *)conflictPointer;
- (BOOL)getAllVersionsOfCloudDocumentWithUniqueIdentifier:(NSNumber *)uniqueIdentifier versions:(JCloudDocumentVersions *)versions;
- (BOOL)openCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier versionIdentifier:(NSData *)versionIdentifier;
- (BOOL)pickCloudDocumentManagerWithUniqueIdentifier:(NSNumber *)uniqueIdentifier versionsHash:(NSString *)md5Hash versionIdentifier:(NSData *)versionIdentifier;


@end
