//
//  jCloudPlugin_Extern.h
//  jCloudPlugin
//
//  Created by Jérémie Di Prizio on 04/11/11.
//  Copyright (c) 2011-2013 jemast software.
//

#import "jCloudPlugin.h"

#ifndef jCloudPlugin_iCloudPlugin_Extern_h
#define jCloudPlugin_iCloudPlugin_Extern_h

extern "C" {
    
    // CLOUD DOCUMENT EXTERN FUNCTIONS
    int PrepareCloudItem(const char *path, bool isDirectory);
    bool DismissCloudItem(int uid);
    int GetCloudItemState(int uid);
    bool CreateOrOpenCloudItem(int uid);
    bool CreateCloudItem(int uid);
    bool OpenCloudItem(int uid);
    bool DeleteCloudItem(int uid, char *deleted);
    bool WriteCloudItemContents(void *bytes, int length, int uid);
    int ReadCloudItemContents(int uid, NSInteger *bytes);
    void SetPersistentDataPath(const char *path);
    bool GetCloudDirectoryPath(NSInteger *value);
    bool GetCloudItemExistence(int uid, char* exists);
    bool GetCloudItemModificationDate(int uid, uint64_t *modificationDate);
    bool CopyCloudItem(int uid, const char *destinationPath, bool overwrite);
    bool MoveCloudItem(int uid, const char *destinationPath, bool overwrite);
    bool CloudItemHasConflictVersions(int uid, char* conflict);
    bool CloudItemFetchAllVersions(int uid, JCloudDocumentVersions *versions);
    bool OpenCloudItemWithVersionIdentifier(int uid, void *versionIdentifier, int versionIdentifierLength);
    bool PickCloudItemWithVersionIdentifier(int uid, void *versionIdentifier, int versionIdentifierLength, const char *versionsHash);
    void SetStateChangeCallbackPointer(NSInteger pointer);
    void SetStatusChangeCallbackPointer(NSInteger pointer);
    void SetProgressChangeCallbackPointer(NSInteger pointer);
    void CloudMetadataSetShouldMessage(bool shouldMessage);
    void CloudMetadataSetCallbackPointer(NSInteger pointer);

    
    // CLOUD DATA EXTERN FUNCTIONS
    void CloudDataSetInt(const char *key, int value);
    bool CloudDataGetInt(const char *key, int *value);
    void CloudDataSetFloat(const char *key, float value);
    bool CloudDataGetFloat(const char *key, float *value);
    void CloudDataSetString(const char *key, const char *value);
    bool CloudDataGetString(const char *key, NSInteger *value);
    bool CloudDataHasKey(const char *key);
    void CloudDataDeleteKey(const char *key);
    void CloudDataDeleteAll();
    void CloudDataSave();
    void CloudDataSetShouldMessage(bool shouldMessage);
    void CloudDataSetCallbackPointer(NSInteger pointer);
    
    
    // CLOUD POLLING EXTERN FUNCTIONS
    bool GetUbiquitousContainerAvailability();
    bool GetUbiquitousStoreAvailability();
    void ResetUbiquityStatus();
    
    // MEMORY MANAGEMENT FUNCTIONS
    void FreeMemory(NSInteger *pointer);
    
    // VARIOUS STUFF
    BOOL IsJailbroken();
}

#endif
