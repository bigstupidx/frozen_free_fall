//
//  CloudDataManager.m
//  iCloudPlugin
//
//  Created by Jérémie Di Prizio on 08/11/11.
//  Copyright (c) 2011-2013 jemast software.
//

#import "CloudDataManager.h"


// EXTERN DECLATIONS FOR UNMANAGED TO MANAGED CALLBACK METHODS
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
#import <UIKit/UIKit.h>
EXTERN_API_C(void) UnitySendMessage(const char *object, const char *method, const char *message) __attribute__((weak));
#elif TARGET_OS_MAC
#import <AppKit/AppKit.h>
typedef void ManagedCallbackPointer(const char *message);
#endif


@implementation CloudDataManager

@synthesize isSaving, messageCallbackPointer;

static Class NSUbiquitousKeyValueStoreClass = nil;


// Quick and dirty singleton implementation
+ (CloudDataManager *)sharedInstance {
    static dispatch_once_t pred = 0;
    static id _sharedObject = nil;
    dispatch_once(&pred, ^{
        _sharedObject = [[self alloc] init];
    });
    return _sharedObject;
}


//////////////////////////////////////
// Initialization & Dealloc Methods // 
//////////////////////////////////////

#pragma mark Initialization & Dealloc Methods

- (id)init {
    if ((self = [super init])) {
        if (NSUbiquitousKeyValueStoreClass == nil)
            NSUbiquitousKeyValueStoreClass = NSClassFromString(@"NSUbiquitousKeyValueStore");
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyValueStoreDidChangeExternally:) name:NSUbiquitousKeyValueStoreDidChangeExternallyNotification object:[NSUbiquitousKeyValueStoreClass defaultStore]];
        
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
#elif TARGET_OS_MAC
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomeActive:) name:NSApplicationDidBecomeActiveNotification object:nil];
#endif
    }
    
    return self;
}

- (void)dealloc {
    [cloudDataFallbackDictionary release];
    [localUbiquityDictionaryRepresentationURL release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    [super dealloc];
}

// Persistent data path sent by Unity
static NSString *persistentDataPath = nil;
+ (void)setPersistentDataPath:(NSString *)path {
    [persistentDataPath release];
    persistentDataPath = [path retain];
}

- (void)setup {
    // We should setup the local kv dictionary path before polling for iCloud
    NSFileManager *asyncFileManager = [[NSFileManager alloc] init];
    NSURL *documentsDirectoryURL = [[asyncFileManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] objectAtIndex:0];
    
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
#elif TARGET_OS_MAC
    // If we ain't sandboxed, fall back to persistent data path
    if ([[[NSProcessInfo processInfo] environment] objectForKey:@"APP_SANDBOX_CONTAINER_ID"] == nil) {
        documentsDirectoryURL = [NSURL fileURLWithPath:persistentDataPath isDirectory:YES];
    }
#endif
    
    localUbiquityDictionaryRepresentationURL = [[documentsDirectoryURL URLByAppendingPathComponent:@".JCloudDataCache" isDirectory:NO] retain];
    
    // If iCloud isn't available, we should prepare a fallback dicitonary in NSUserDefaults
    if (![self isCloudAvailable]) {
        NSDictionary *userDefaultsDictionary = [[NSUserDefaults standardUserDefaults] objectForKey:@"jCloudDataFallbackDictionary"];
        if (userDefaultsDictionary)
            cloudDataFallbackDictionary = [[NSMutableDictionary dictionaryWithDictionary:userDefaultsDictionary] retain];
        else
            cloudDataFallbackDictionary = [[NSMutableDictionary dictionary] retain];
    } else {
        // Check if we had a fallback dictionary in place
        NSDictionary *userDefaultsDictionary = [[NSUserDefaults standardUserDefaults] objectForKey:@"jCloudDataFallbackDictionary"];
        if (userDefaultsDictionary != nil) {
            // Apply to iCloud store
            for (NSString *key in userDefaultsDictionary)
                [[NSUbiquitousKeyValueStoreClass defaultStore] setObject:[userDefaultsDictionary objectForKey:key] forKey:key];
            
            // Delete fallback
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"jCloudDataFallbackDictionary"];
            
            // Synchronize
            [[NSUserDefaults standardUserDefaults] synchronize];
            [[NSUbiquitousKeyValueStoreClass defaultStore] synchronize];
        }
        
        // Make a copy of the ubiquitous kv-store to be able to retain old values on change
        if (![asyncFileManager fileExistsAtPath:localUbiquityDictionaryRepresentationURL.path]) {
            [[[NSUbiquitousKeyValueStoreClass defaultStore] dictionaryRepresentation] writeToURL:localUbiquityDictionaryRepresentationURL atomically:YES];
        }
    }
    
    [asyncFileManager release];
}


static BOOL didCheckUbiquityStatus = false;

- (void)resetUbiquityStatus {
    didCheckUbiquityStatus = false;
    [self setup];
}

- (BOOL)isCloudAvailable {
    static BOOL isCloudAvailable = NO;
    
    if (!didCheckUbiquityStatus) {
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
#elif TARGET_OS_MAC
        // Make sure we are sandboxed
        BOOL isSandboxed = ([[[NSProcessInfo processInfo] environment] objectForKey:@"APP_SANDBOX_CONTAINER_ID"] != nil);
        
        // Make sure NSUbiquitousKeyValueStoreClass synchronize answers yes only if we are sandboxed
        if (isSandboxed)
#endif
            isCloudAvailable = [[NSUbiquitousKeyValueStoreClass defaultStore] synchronize];
        
        // No need to observe for notifications anymore
        if (!isCloudAvailable)
            [[NSNotificationCenter defaultCenter] removeObserver:self];
    
        didCheckUbiquityStatus = true;
    }

    return isCloudAvailable;
}

- (void)applicationDidBecomeActive:(NSNotification *)notification {
    [self resetUbiquityStatus];
}

- (BOOL)shouldMessage {
    @synchronized(self) {
        return shouldMessage;
    }
}

- (void)setShouldMessage:(BOOL)value {
    @synchronized(self) {
        shouldMessage = value;
    }
    
    // Lazy setup so we can check for changes on launch
    if (!didCheckUbiquityStatus)
        [self setup];
}


///////////////////////////////////////////
// Key-Value Get/Set/Remove/Save Methods // 
///////////////////////////////////////////

#pragma mark Key-Value Get/Set/Remove/Save Method

- (void)setInt:(NSInteger)value forKey:(NSString *)key {
    // Lazy setup so we can check for changes on launch
    if (!didCheckUbiquityStatus)
        [self setup];
    
    // Set value for key
    if ([self isCloudAvailable]) {
        [[NSUbiquitousKeyValueStoreClass defaultStore] setLongLong:value forKey:key];
        [self saveLocal];
    } else {
        [cloudDataFallbackDictionary setObject:[NSNumber numberWithInteger:value] forKey:key];
    }
}

- (BOOL)getIntForKey:(NSString *)key value:(NSInteger *)value {
    // Lazy setup so we can check for changes on launch
    if (!didCheckUbiquityStatus)
        [self setup];
    
    // Get value for key
    if ([self isCloudAvailable]) {
        // Check that we have this key
        if ([[[NSUbiquitousKeyValueStoreClass defaultStore] dictionaryRepresentation] valueForKey:key] == nil)
            return NO;
    
        // If yes, set value and return valid
        *value = (NSInteger)[[NSUbiquitousKeyValueStoreClass defaultStore] longLongForKey:key];
        return YES;
    } else {
        // Check that we have this key
        NSNumber *intObject = [cloudDataFallbackDictionary objectForKey:key];
        if (intObject == nil)
            return NO;
        
        // If yes, set value and return valid
        *value = [intObject integerValue];
        return YES;
    }
}

- (void)setFloat:(float)value forKey:(NSString *)key {
    // Lazy setup so we can check for changes on launch
    if (!didCheckUbiquityStatus)
        [self setup];
    
    // Set value for key
    if ([self isCloudAvailable]) {
        [[NSUbiquitousKeyValueStoreClass defaultStore] setDouble:value forKey:key];
        [self saveLocal];
    } else {
        [cloudDataFallbackDictionary setObject:[NSNumber numberWithFloat:value] forKey:key];        
    }
}

- (BOOL)getFloatForKey:(NSString *)key value:(float *)value {
    // Lazy setup so we can check for changes on launch
    if (!didCheckUbiquityStatus)
        [self setup];
    
    if ([self isCloudAvailable]) {
        // Check that we have this key
        if ([[[NSUbiquitousKeyValueStoreClass defaultStore] dictionaryRepresentation] valueForKey:key] == nil)
            return NO;
    
        // If yes, set value and return valid
        *value = [[NSUbiquitousKeyValueStoreClass defaultStore] doubleForKey:key];
        return YES;
    } else {
        // Check that we have this key
        NSNumber *floatObject = [cloudDataFallbackDictionary objectForKey:key];
        if (floatObject == nil)
            return NO;
        
        // If yes, set value and return valid
        *value = [floatObject integerValue];
        return YES;
    }
}

- (void)setString:(NSString *)value forKey:(NSString *)key {
    // Lazy setup so we can check for changes on launch
    if (!didCheckUbiquityStatus)
        [self setup];
    
    // Set value for key
    if ([self isCloudAvailable]) {
        [[NSUbiquitousKeyValueStoreClass defaultStore] setString:value forKey:key];
        [self saveLocal];
    } else {
        [cloudDataFallbackDictionary setObject:value forKey:key];        
    }
}

- (BOOL)getStringForKey:(NSString *)key value:(NSString **)value {
    // Lazy setup so we can check for changes on launch
    if (!didCheckUbiquityStatus)
        [self setup];
    
    if ([self isCloudAvailable]) {
        // Check that we have this key
        if ([[[NSUbiquitousKeyValueStoreClass defaultStore] dictionaryRepresentation] valueForKey:key] == nil)
            return NO;
    
        // If yes, set value and return valid
        if (value)
            *value = [[NSUbiquitousKeyValueStoreClass defaultStore] stringForKey:key];
        
        return YES;
    } else {
        // Check that we have this key
        NSString *stringObject = [cloudDataFallbackDictionary objectForKey:key];
        if (stringObject == nil)
            return NO;
        
        // If yes, set value and return valid
        if (value)
            *value = stringObject;
        
        return YES;
    }
}

- (BOOL)hasKey:(NSString *)key {
    // Lazy setup so we can check for changes on launch
    if (!didCheckUbiquityStatus)
        [self setup];
    
    // Check if we have key
    if ([self isCloudAvailable]) {
        return ([[[NSUbiquitousKeyValueStoreClass defaultStore] dictionaryRepresentation] valueForKey:key] != nil);
    } else {
        return ([cloudDataFallbackDictionary objectForKey:key] != nil);
    }
}

- (void)deleteKey:(NSString *)key {
    // Lazy setup so we can check for changes on launch
    if (!didCheckUbiquityStatus)
        [self setup];
    
    // Delete key
    if ([self isCloudAvailable]) {
        [[NSUbiquitousKeyValueStoreClass defaultStore] removeObjectForKey:key];
        [self saveLocal];
    } else {
        [cloudDataFallbackDictionary removeObjectForKey:key];
    }
}

- (void)deleteAll {
    // Lazy setup so we can check for changes on launch
    if (!didCheckUbiquityStatus)
        [self setup];
    
    // Delete all keys
    if ([self isCloudAvailable]) {
        for (NSString *key in [[NSUbiquitousKeyValueStoreClass defaultStore] dictionaryRepresentation])
            [[NSUbiquitousKeyValueStoreClass defaultStore] removeObjectForKey:key];
        [self saveLocal];
    } else {
        [cloudDataFallbackDictionary removeAllObjects];
    }
}

- (void)save {
    // Lazy setup so we can check for changes on launch
    if (!didCheckUbiquityStatus)
        [self setup];
    
    if ([self isCloudAvailable]) {
        [[NSUbiquitousKeyValueStoreClass defaultStore] synchronize];
        [self saveLocal];
    } else {
        [[NSUserDefaults standardUserDefaults] setObject:cloudDataFallbackDictionary forKey:@"jCloudDataFallbackDictionary"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

- (void)saveLocal {
    // Make sure we aren't already saving
    @synchronized(self) {
        if (isSaving)
            return;
        
        // Mark as saving
        isSaving = YES;
    }
    
    
    // Create a timer that will periodically check for writability
    dispatch_source_t timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0));
    
    // Prepare a 100ms timer with 10ms leeway
    dispatch_source_set_timer(timer, dispatch_walltime(NULL, 100ull * NSEC_PER_MSEC), 100ull * NSEC_PER_MSEC, 10ull * NSEC_PER_MSEC);
    dispatch_source_set_event_handler(timer, ^(void) {
        @synchronized(self) {
            // Mark as not saving anymore
            isSaving = NO;
                
            // Write new contents
            [[[NSUbiquitousKeyValueStoreClass defaultStore] dictionaryRepresentation] writeToURL:localUbiquityDictionaryRepresentationURL atomically:YES];
        }
            
        // Cancel and release timer
        dispatch_source_cancel(timer);
        dispatch_release(timer);
    });
    
    // Fire timer
    dispatch_resume(timer);
}

- (void)keyValueStoreDidChangeExternally:(NSNotification *)notification {
    // Pass the notification down to Unity
    if (self.shouldMessage) {
        // Compute message to send
        NSNumber *reason = [[notification userInfo] objectForKey:NSUbiquitousKeyValueStoreChangeReasonKey];
        NSArray *changedKeys = [[notification userInfo] objectForKey:NSUbiquitousKeyValueStoreChangedKeysKey];
        NSMutableString *message = [NSMutableString stringWithFormat:@"%i.%lu", reason.intValue, (unsigned long)changedKeys.count];
        
        // Get a list of old & new values
        NSMutableDictionary *oldValues = [[NSMutableDictionary alloc] init];
        NSMutableDictionary *newValues = [[NSMutableDictionary alloc] init];
        
        NSDictionary *oldValuesDictionary = [[NSDictionary alloc] initWithContentsOfURL:localUbiquityDictionaryRepresentationURL];
        
        for (NSString *key in changedKeys) {
            // Append key length
            [message appendFormat:@".%lu", (unsigned long)[key lengthOfBytesUsingEncoding:NSUTF8StringEncoding]];
            
            // Append old value length
            id oldValue = [oldValuesDictionary valueForKey:key];
            if (oldValue != nil) {
                // Old value is defined
                if ([oldValue isKindOfClass:[NSString class]])
                {
                    [message appendString:@".3"];
                    [message appendFormat:@".%lu", (unsigned long)[(NSString *)oldValue lengthOfBytesUsingEncoding:NSUTF8StringEncoding]];
                    [oldValues setObject:oldValue forKey:key];
                } else if ([oldValue isKindOfClass:[NSNumber class]]) {
                    BOOL appendValue = YES;
                    CFNumberType numberType = CFNumberGetType((CFNumberRef)oldValue);
                    switch (numberType) {
                        case kCFNumberSInt8Type:
                        case kCFNumberSInt16Type:
                        case kCFNumberSInt32Type:
                        case kCFNumberSInt64Type:
                            [message appendString:@".1"];
                            break;
                        case kCFNumberFloat32Type:
                        case kCFNumberFloat64Type:
                            [message appendString:@".2"];
                            break;
                        default:
                            [message appendString:@".0.0"];
                            appendValue = NO;
                            break;
                    }
                    
                    if (appendValue) {
                        NSString *stringValue = [(NSNumber *)oldValue stringValue];
                        [message appendFormat:@".%lu", (unsigned long)[stringValue lengthOfBytesUsingEncoding:NSUTF8StringEncoding]];
                        [oldValues setObject:stringValue forKey:key];
                    }
                }
            } else {
                // Old value is null
                [message appendString:@".0.0"];
            }
            
            // Append new value length
            id newValue = [[[NSUbiquitousKeyValueStoreClass defaultStore] dictionaryRepresentation] valueForKey:key];
            if (newValue != nil) {
                // New value is defined
                if ([newValue isKindOfClass:[NSString class]])
                {
                    [message appendString:@".3"];
                    [message appendFormat:@".%lu", (unsigned long)[(NSString *)newValue lengthOfBytesUsingEncoding:NSUTF8StringEncoding]];
                    [newValues setObject:newValue forKey:key];
                } else if ([newValue isKindOfClass:[NSNumber class]]) {
                    BOOL appendValue = YES;
                    CFNumberType numberType = CFNumberGetType((CFNumberRef)newValue);
                    switch (numberType) {
                        case kCFNumberSInt8Type:
                        case kCFNumberSInt16Type:
                        case kCFNumberSInt32Type:
                        case kCFNumberSInt64Type:
                            [message appendString:@".1"];
                            break;
                        case kCFNumberFloat32Type:
                        case kCFNumberFloat64Type:
                            [message appendString:@".2"];
                            break;
                        default:
                            [message appendString:@".0.0"];
                            appendValue = NO;
                            break;
                    }
                    
                    if (appendValue) {
                        NSString *stringValue = [(NSNumber *)newValue stringValue];
                        [message appendFormat:@".%lu", (unsigned long)[stringValue lengthOfBytesUsingEncoding:NSUTF8StringEncoding]];
                        [newValues setObject:stringValue forKey:key];
                    }
                }
            } else {
                // New value is null
                [message appendString:@".0.0"];
                
            }
        }
        [oldValuesDictionary release];
        
        // Append changed keys
        [message appendString:@"."];
        for (NSString *key in changedKeys) {
            [message appendString:key];
            
            NSString *oldValue = [oldValues objectForKey:key];
            if (oldValue != nil)
                [message appendString:oldValue];
            
            NSString *newValue = [newValues objectForKey:key];
            if (newValue != nil)
                [message appendString:newValue];
        }
        
        [oldValues release];
        [newValues release];
        
        // Save the new changes
        [self saveLocal];

        
        dispatch_async(dispatch_get_main_queue(),^ {
#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
            UnitySendMessage("JCloudManager", "KeyValueStoreDidChangeExternally", [message UTF8String]);
#elif TARGET_OS_MAC
            if (messageCallbackPointer != 0) // Prevent BAD_ACCESS in case something goes horribly wrong
                (*((ManagedCallbackPointer *)messageCallbackPointer))([message UTF8String]);
#endif
        });
    } else {
        // No messaging, update the local dictionary nevertheless
        [self saveLocal];
    }
}


@end
